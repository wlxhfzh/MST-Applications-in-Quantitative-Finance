import pandas as pd
import numpy as np
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx
from tqdm import tqdm
import os
import matplotlib.pyplot as plt
import seaborn as sns

# ========== 0. 全局配置 ==========
# --- 文件路径 ---
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
MARKET_CAP_FILE = 'stock_data/market_cap.csv'
TURNOVER_VALUE_FILE = 'stock_data/turnover_value.csv'
HS300_FILE = 'stock_data/HS300_monthly_return.csv'
OUTPUT_FOLDER = 'output'
MST_METRICS_CACHE_FILE = 'mst_metrics_cache_final.parquet'

# --- 分析参数 ---
NUM_GROUPS = 10  # 分成10组
VOLATILITY_LOOKBACK = 126
MOMENTUM_LOOKBACK = 63

# --- 环境设置 ---
os.makedirs(OUTPUT_FOLDER, exist_ok=True)
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception:
    print("SimHei 字体未找到，图表中文可能无法正常显示。")

# ========== 1. 数据准备 ==========
print("数据准备...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
daily_returns = df_prices.pct_change()

# 加载市值和交易额数据
try:
    df_cap = pd.read_csv(MARKET_CAP_FILE, index_col=0, parse_dates=True)
    df_turnover = pd.read_csv(TURNOVER_VALUE_FILE, index_col=0, parse_dates=True)
except FileNotFoundError as e:
    raise FileNotFoundError(f"错误：缺少因子分析所需的数据文件。 {e}")


# ========== 2. EdgeScore信号计算 (复用您的逻辑) ==========
def calculate_mst_metrics(price_window):
    returns = price_window.pct_change().dropna()
    if len(returns) < 2 or len(returns.columns) < 2: return pd.DataFrame()
    corr = returns.corr().fillna(0)
    dist = np.sqrt(2 * (1 - corr))
    mst_sparse = minimum_spanning_tree(dist)
    G = nx.from_scipy_sparse_array(mst_sparse)
    node_mapping = {i: code for i, code in enumerate(corr.columns)}
    G = nx.relabel_nodes(G, node_mapping)
    if len(G.nodes) == 0: return pd.DataFrame()
    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except ValueError:
        levels = {node: 0 for node in G.nodes()}
    degs = dict(G.degree())
    bc = nx.betweenness_centrality(G, weight='weight')
    return pd.DataFrame({
        '股票代码': list(G.nodes()), 'NTL': [levels.get(n, 0) for n in G.nodes()],
        'ND': [degs.get(n, 0) for n in G.nodes()], 'BC': [bc.get(n, 0) for n in G.nodes()],
    })


if os.path.exists(MST_METRICS_CACHE_FILE):
    print(f"加载缓存文件: '{MST_METRICS_CACHE_FILE}'...")
    signals_df = pd.read_parquet(MST_METRICS_CACHE_FILE)
else:
    print(f"未找到缓存文件。正在生成所有指标...")
    all_monthly_scores = []
    max_lookback = max(VOLATILITY_LOOKBACK, MOMENTUM_LOOKBACK)
    first_valid_date = df_prices.index[0] + pd.DateOffset(days=max_lookback)
    monthly_groups = df_prices[df_prices.index >= first_valid_date].groupby(pd.Grouper(freq='MS'))

    for period_start, price_window in tqdm(monthly_groups, desc="计算所有指标"):
        if len(price_window) < 20: continue
        metrics_df = calculate_mst_metrics(price_window)
        if metrics_df.empty: continue

        vol_start = period_start - pd.DateOffset(days=VOLATILITY_LOOKBACK)
        volatility = daily_returns.loc[vol_start:period_start].std() * np.sqrt(252)
        metrics_df['volatility'] = metrics_df['股票代码'].map(volatility)

        metrics_df['NTL_rank'] = metrics_df['NTL'].rank(pct=True)
        metrics_df['ND_rank'] = metrics_df['ND'].rank(pct=True)
        metrics_df['BC_rank'] = metrics_df['BC'].rank(pct=True)
        metrics_df['EdgeScore'] = metrics_df['NTL_rank'] + (1 - metrics_df['ND_rank']) + (1 - metrics_df['BC_rank'])
        metrics_df['月份'] = period_start
        all_monthly_scores.append(metrics_df)

    signals_df = pd.concat(all_monthly_scores).reset_index(drop=True)
    signals_df['生效月份'] = signals_df.groupby('股票代码')['月份'].shift(-1)
    signals_df = signals_df.dropna(subset=['生效月份'])
    signals_df.to_parquet(MST_METRICS_CACHE_FILE)
    print(f"缓存文件 '{MST_METRICS_CACHE_FILE}' 已保存。")

# ========== 3. 分层回测与特征分析 ==========
print("开始执行分层分析...")

# 使用 'ME' (Month-End) 避免 FutureWarning
monthly_returns = df_prices.resample('ME').last().pct_change()

all_groups_data = []
rebalance_dates = sorted(signals_df['生效月份'].unique())

for date in tqdm(rebalance_dates, desc="逐月分组回测"):
    if pd.isna(date): continue

    # ==================== 代码修改部分 START ====================
    # 核心修正：手动查找实际的交易日，以兼容旧版Pandas
    # 获取市值数据中所有 >= date 的日期
    future_dates = df_cap.index[df_cap.index >= date]

    if future_dates.empty:
        # 如果 'date' 晚于市值数据的最后一个日期，则跳过
        print(f"警告: 无法在市值/交易额数据中找到 {date} 或之后的日期，已跳过。")
        continue

    # 第一个未来日期就是我们需要的实际交易日
    actual_char_date = future_dates[0]
    # ===================== 代码修改部分 END =====================

    # 1. 获取当月信号并分组
    current_signals = signals_df[signals_df['生效月份'] == date].copy()
    current_signals = current_signals.sort_values('EdgeScore', ascending=False)
    current_signals = current_signals.dropna(subset=['EdgeScore'])

    try:
        current_signals['Group'] = pd.qcut(current_signals['EdgeScore'], NUM_GROUPS,
                                           labels=[f'D{i + 1}' for i in range(NUM_GROUPS)])
    except ValueError:
        print(f"警告: {date} 股票数量不足，无法分为 {NUM_GROUPS} 组，已跳过。")
        continue

    # 2. 计算下个月的收益率及当月特征
    next_month = date.to_period('M')

    # 确保下个月的收益率存在
    matching_returns = monthly_returns.index[monthly_returns.index.to_period('M') == next_month]
    if matching_returns.empty:
        continue
    return_col_date = matching_returns[0]

    # 提取当月特征 (使用修正后的 actual_char_date)
    current_signals['市值'] = current_signals['股票代码'].map(df_cap.loc[actual_char_date])
    current_signals['交易额'] = current_signals['股票代码'].map(df_turnover.loc[actual_char_date])

    # 3. 按组计算
    # 在旧版pandas中，groupby后直接迭代可能不包含所有label，需要用observed=False
    try:
        grouped = current_signals.groupby('Group', observed=False)
    except TypeError:  # 更旧的版本可能不支持 observed 参数
        grouped = current_signals.groupby('Group')

    for group_name, group_df in grouped:
        group_stocks = group_df['股票代码'].tolist()
        group_return = monthly_returns.loc[return_col_date, group_stocks].mean()

        all_groups_data.append({
            '日期': return_col_date,
            'Group': group_name,
            '月度收益率': group_return,
            'volatility': group_df['volatility'].mean(),
            '市值': group_df['市值'].mean(),
            '交易额': group_df['交易额'].mean()
        })

analysis_results = pd.DataFrame(all_groups_data)
print("分层分析计算完成。")

# ========== 4. 结果整理与可视化 ==========
# (此部分无需修改)
print("整理结果并生成图表...")

# --- 图1: 累计收益率折线图 ---
plt.figure(figsize=(18, 9))
palette = sns.color_palette("viridis", n_colors=NUM_GROUPS)

# 计算每个组的累计净值
group_labels = [f'D{i + 1}' for i in range(NUM_GROUPS)]
for i, group_name in enumerate(group_labels):
    group_data = analysis_results[analysis_results['Group'] == group_name]
    if group_data.empty: continue
    group_returns = group_data.set_index('日期')['月度收益率']
    group_net_value = (1 + group_returns).cumprod()
    plt.plot(group_net_value.index, group_net_value, label=group_name, color=palette[i])

# 计算并绘制基准
try:
    hs300_returns = pd.read_csv(HS300_FILE, parse_dates=['月份'], index_col='月份')['沪深300收益率']
    # 确保基准的起始点和回测对齐
    if 'group_net_value' in locals() and not group_net_value.empty:
        first_date = group_net_value.index[0]
        hs300_returns = hs300_returns[hs300_returns.index >= first_date]
        hs300_net_value = (1 + hs300_returns).cumprod()
        plt.plot(hs300_net_value.index, hs300_net_value, label='沪深300基准', color='black', linestyle='--',
                 linewidth=2)
except Exception as e:
    print(f"警告：处理基准数据失败。{e}")

plt.title('EdgeScore分层回测累计净值', fontsize=18)
plt.xlabel('日期', fontsize=12)
plt.ylabel('累计净值', fontsize=12)
plt.legend(title='分组 (D1:高EdgeScore)', bbox_to_anchor=(1.02, 1), loc='upper left')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout(rect=[0, 0, 0.88, 1])
plt.savefig(os.path.join(OUTPUT_FOLDER, 'factor_decile_cumulative_return.png'))
#plt.show()

# --- 图2: 月度波动率折线图 ---
plt.figure(figsize=(18, 9))
vol_pivot = analysis_results.pivot_table(index='日期', columns='Group', values='volatility')
for i, group_name in enumerate(group_labels):
    if group_name in vol_pivot.columns:
        plt.plot(vol_pivot.index, vol_pivot[group_name], label=group_name, color=palette[i])

plt.title('EdgeScore分层月度波动率', fontsize=18)
plt.xlabel('日期', fontsize=12)
plt.ylabel('组内平均年化波动率', fontsize=12)
plt.legend(title='分组 (D1:高EdgeScore)', bbox_to_anchor=(1.02, 1), loc='upper left')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout(rect=[0, 0, 0.88, 1])
plt.savefig(os.path.join(OUTPUT_FOLDER, 'factor_decile_volatility.png'))
#plt.show()

# --- 计算平均特征用于柱状图 ---
mean_characteristics = analysis_results.groupby('Group')[['市值', '交易额']].mean().reset_index()
print("\n--- 各分组平均特征 ---")
print(mean_characteristics)

# --- 图3: 平均市值柱状图 ---
plt.figure(figsize=(12, 7))
sns.barplot(x='Group', y='市值', data=mean_characteristics, palette='viridis', order=group_labels)
plt.title('EdgeScore分组 vs. 平均市值', fontsize=16)
plt.xlabel('EdgeScore 分组 (D1: 最高 -> D10: 最低)', fontsize=12)
plt.ylabel('平均市值 (元)', fontsize=12)
plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.savefig(os.path.join(OUTPUT_FOLDER, 'factor_decile_firm_size.png'))
#plt.show()

# --- 图4: 平均交易额柱状图 ---
plt.figure(figsize=(12, 7))
sns.barplot(x='Group', y='交易额', data=mean_characteristics, palette='viridis', order=group_labels)
plt.title('EdgeScore分组 vs. 平均交易额', fontsize=16)
plt.xlabel('EdgeScore 分组 (D1: 最高 -> D10: 最低)', fontsize=12)
plt.ylabel('平均日均交易额 (元)', fontsize=12)
plt.ticklabel_format(style='sci', axis='y', scilimits=(0, 0))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.savefig(os.path.join(OUTPUT_FOLDER, 'factor_decile_trading_volume.png'))
plt.show()

print("\n全部分析完成！所有图表已保存在 'output' 文件夹中。")