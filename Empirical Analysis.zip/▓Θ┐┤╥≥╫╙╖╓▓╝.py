import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import datetime
from tqdm import tqdm
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx
from scipy.stats import skew

# ==============================================================================
# ========== 0. 全局配置与日志初始化 ==========
# ==============================================================================
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
OUTPUT_FOLDER = 'output'
FACTOR_LOOKBACK_DAYS = 21

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
logger = logging.getLogger(__name__)

try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception as e:
    logger.warning(f"设置中文字体失败: {e}。")

# ==============================================================================
# ========== 1. 数据加载 ==========
# ==============================================================================
logger.info("=" * 60)
logger.info("========== 1. 数据加载 ==========")
logger.info("=" * 60)

logger.info(f"STEP: 加载价格数据 '{PRICE_FILE}'...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
df_prices.columns = df_prices.columns.astype(str)

# ==============================================================================
# ========== 2. 核心逻辑：滚动计算所有指标（含SR） ==========
# ==============================================================================
logger.info("=" * 60)
logger.info("========== 2. 核心逻辑：滚动计算所有指标（含 SR） ==========")
logger.info("=" * 60)


def calculate_all_metrics(price_window):
    """计算并返回包含所有网络指标（NTL, ND, BC, SR, SR_mean, EdgeScore）的DataFrame"""
    stock_codes = price_window.columns.astype(str)
    returns = price_window.pct_change().dropna()
    if len(returns) < 10 or len(stock_codes) < 2:
        return None

    corr = returns.corr().fillna(0)
    dist = np.sqrt(np.clip(2 * (1 - corr), 0, None))  # 保证非负
    # 最小生成树（稀疏）
    try:
        mst_sparse = minimum_spanning_tree(dist.values)
        G = nx.from_scipy_sparse_array(mst_sparse)
    except Exception as e:
        logger.debug(f"MST 构建失败: {e}")
        return None

    node_mapping = {i: code for i, code in enumerate(stock_codes)}
    try:
        G = nx.relabel_nodes(G, node_mapping)
    except Exception:
        pass

    if len(G.nodes) == 0:
        return None

    # root: 节点度最大的顶点
    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except Exception:
        levels = {node: 0 for node in G.nodes()}

    degs = dict(G.degree())
    try:
        bc = nx.betweenness_centrality(G, weight='weight')
    except Exception:
        # 若计算中出错则全部设0
        bc = {n: 0.0 for n in G.nodes()}

    # ===== 计算 SR（node strength based on similarity） =====
    # 取每条边的 distance (weight) 并映射为 similarity
    # sim = 1 / (1 + d)  -> d 越小 sim 越大，保证数值在 (0,1]
    sims = {}
    dist_vals = []
    for u, v, data in G.edges(data=True):
        # networkx edge 'weight' should be the distance from MST; fallback to 0 if missing
        d = float(data.get('weight', 0.0))
        dist_vals.append(d)
    if len(dist_vals) == 0:
        dmax = 1.0
    else:
        dmax = max(dist_vals)
        if dmax <= 0:
            dmax = 1.0

    for u, v, data in G.edges(data=True):
        d = float(data.get('weight', 0.0))
        # similarity choice: 1/(1+d). 另一种可选 sim = max(0, 1 - d/dmax)
        sim = 1.0 / (1.0 + d)
        sims[(u, v)] = sim
        sims[(v, u)] = sim

    # node SR: sum(sim over neighbors). SR_mean: SR / degree (平均邻居相似度)
    sr = {}
    sr_mean = {}
    for node in G.nodes():
        neighs = list(G.adj[node])
        if len(neighs) == 0:
            sr[node] = 0.0
            sr_mean[node] = 0.0
            continue
        ssum = sum(sims.get((node, nb), 0.0) for nb in neighs)
        sr[node] = ssum
        sr_mean[node] = ssum / len(neighs) if len(neighs) > 0 else 0.0

    # assemble df
    df = pd.DataFrame(index=list(G.nodes()))
    df['NTL'] = pd.Series(levels)
    df['ND'] = pd.Series(degs)
    df['BC'] = pd.Series(bc)
    df['SR'] = pd.Series(sr)
    df['SR_mean'] = pd.Series(sr_mean)
    df = df.fillna(0)

    # EdgeScore（原始组合，用以对比）
    weights = {"NTL": 2.0, "ND": -0.2, "BC": -0.1}
    df['EdgeScore'] = (
        df['NTL'] * weights['NTL'] +
        df['ND'] * weights['ND'] +
        df['BC'] * weights['BC']
    )

    return df


# --- 采用月度滚动计算 ---
rebalance_dates = df_prices.resample('M').last().index
all_factor_data = []

logger.info("开始在每个月度时间点上滚动计算因子（含 SR）...")
for date in tqdm(rebalance_dates, desc="滚动计算因子"):
    past_prices = df_prices.loc[:date].tail(FACTOR_LOOKBACK_DAYS)
    factor_df = calculate_all_metrics(past_prices)
    if factor_df is not None:
        factor_df['日期'] = date
        all_factor_data.append(factor_df)

if not all_factor_data:
    logger.critical("未能计算任何有效的因子数据！程序终止。")
else:
    master_df = pd.concat(all_factor_data)
    logger.info(f"因子计算完成，共生成 {len(master_df)} 条记录。")

    # 保存 master_df 以便后续分析
    master_out = os.path.join(OUTPUT_FOLDER, 'master_df_with_SR.csv')
    master_df.to_csv(master_out)
    logger.info(f"已保存 master_df（含 SR）到: {master_out}")

    # ==============================================================================
    # ========== 3. 因子分布可视化（含SR） ==========
    # ==============================================================================
    logger.info("=" * 60)
    logger.info("========== 3. 因子分布可视化（含 SR） ==========")
    logger.info("=" * 60)

    # --- ND distribution ---
    # plt.figure(figsize=(12, 7))
    # sns.countplot(x='ND', data=master_df, palette='viridis')
    # plt.title('ND (节点度) 在整个样本期间的分布', fontsize=16)
    # plt.xlabel('ND 值', fontsize=12)
    # plt.ylabel('股票-月份 数量 (频数)', fontsize=12)
    # plt.grid(axis='y', linestyle='--', alpha=0.7)
    # nd_dist_path = os.path.join(OUTPUT_FOLDER, 'distribution_ND.png')
    # plt.savefig(nd_dist_path)
    # logger.info(f"ND 分布图已保存至: {nd_dist_path}")
    # plt.close()
    #
    # # --- NTL distribution ---
    # plt.figure(figsize=(12, 7))
    # sns.countplot(x='NTL', data=master_df, palette='plasma')
    # plt.title('NTL (到根节点距离) 在整个样本期间的分布', fontsize=16)
    # plt.xlabel('NTL 值', fontsize=12)
    # plt.ylabel('股票-月份 数量 (频数)', fontsize=12)
    # plt.grid(axis='y', linestyle='--', alpha=0.7)
    # ntl_dist_path = os.path.join(OUTPUT_FOLDER, 'distribution_NTL.png')
    # plt.savefig(ntl_dist_path)
    # logger.info(f"NTL 分布图已保存至: {ntl_dist_path}")
    # plt.close()
    #
    # # --- BC distribution ---
    # plt.figure(figsize=(12, 7))
    # sns.histplot(master_df['BC'], kde=True, bins=50)
    # plt.title('BC (介数中心性) 在整个样本期间的分布', fontsize=16)
    # plt.xlabel('BC 值', fontsize=12)
    # plt.ylabel('频数', fontsize=12)
    # plt.grid(axis='y', linestyle='--', alpha=0.7)
    # bc_dist_path = os.path.join(OUTPUT_FOLDER, 'distribution_BC.png')
    # plt.savefig(bc_dist_path)
    # logger.info(f"BC 分布图已保存至: {bc_dist_path}")
    # plt.close()
    #
    # # --- EdgeScore distribution ---
    # plt.figure(figsize=(12, 7))
    # sns.histplot(master_df['EdgeScore'], kde=True, bins=50, color='coral')
    # plt.title('EdgeScore (最终因子 raw) 在整个样本期间的分布', fontsize=16)
    # plt.xlabel('EdgeScore 值', fontsize=12)
    # plt.ylabel('频数', fontsize=12)
    # plt.grid(axis='y', linestyle='--', alpha=0.7)
    # edgescore_dist_path = os.path.join(OUTPUT_FOLDER, 'distribution_EdgeScore.png')
    # plt.savefig(edgescore_dist_path)
    # logger.info(f"EdgeScore 分布图已保存至: {edgescore_dist_path}")
    # plt.close()

    # ===== 新增：SR 分布图与统计 =====
    # SR 是连续的（sum of neighbor similarities），SR_mean 为归一化到 degree 的平均邻居相似度
    # 画直方图 + 箱线图，并输出描述统计
    sr_stats = master_df['SR'].describe()
    sr_skew = skew(master_df['SR'].dropna())
    logger.info(f"SR 描述统计:\n{sr_stats.to_string()}")
    logger.info(f"SR 偏度 (skew): {sr_skew:.4f}")

    plt.figure(figsize=(12, 6))
    sns.histplot(master_df['SR'], kde=True, bins=60, color='teal')
    plt.title('SR (节点强度：邻居相似度之和) 在整个样本期间的分布', fontsize=16)
    plt.xlabel('SR 值', fontsize=12)
    plt.ylabel('频数', fontsize=12)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    sr_hist_path = os.path.join(OUTPUT_FOLDER, 'distribution_SR_hist.png')
    plt.savefig(sr_hist_path)
    logger.info(f"SR 直方图已保存至: {sr_hist_path}")
    plt.close()

    plt.figure(figsize=(10, 4))
    sns.boxplot(x=master_df['SR'], color='lightseagreen')
    plt.title('SR 值箱线图（整体分布）', fontsize=14)
    plt.xlabel('SR', fontsize=12)
    sr_box_path = os.path.join(OUTPUT_FOLDER, 'distribution_SR_box.png')
    plt.savefig(sr_box_path)
    logger.info(f"SR 箱线图已保存至: {sr_box_path}")
    plt.close()

    # SR_mean 分布
    sr_mean_stats = master_df['SR_mean'].describe()
    sr_mean_skew = skew(master_df['SR_mean'].dropna())
    logger.info(f"SR_mean 描述统计:\n{sr_mean_stats.to_string()}")
    logger.info(f"SR_mean 偏度 (skew): {sr_mean_skew:.4f}")

    plt.figure(figsize=(12, 6))
    sns.histplot(master_df['SR_mean'], kde=True, bins=60, color='purple')
    plt.title('SR_mean (平均邻居相似度) 在整个样本期间的分布', fontsize=16)
    plt.xlabel('SR_mean 值', fontsize=12)
    plt.ylabel('频数', fontsize=12)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    sr_mean_hist_path = os.path.join(OUTPUT_FOLDER, 'distribution_SR_mean_hist.png')
    plt.savefig(sr_mean_hist_path)
    logger.info(f"SR_mean 直方图已保存至: {sr_mean_hist_path}")
    plt.close()

    # 保存 SR 的描述统计到 CSV 以便后续分析
    desc = pd.DataFrame({
        'SR': master_df['SR'].describe(),
        'SR_mean': master_df['SR_mean'].describe()
    })
    desc_path = os.path.join(OUTPUT_FOLDER, 'SR_descriptive_stats.csv')
    desc.to_csv(desc_path)
    logger.info(f"已保存 SR 描述统计到: {desc_path}")

    # 显示少量 SR 的数值样例（方便快速检查）
    sample_path = os.path.join(OUTPUT_FOLDER, 'SR_sample_values.csv')
    master_df[['SR', 'SR_mean']].head(200).to_csv(sample_path)
    logger.info(f"已保存 SR 样例（前200行）到: {sample_path}")

logger.info("========== 全部分析完成 ==========")