#!/usr/bin/env python3
"""
EdgeScore / NTL / SR vs Market Cap decile analysis

Purpose:
- For each metric (EdgeScore_new, NTL, SR_mean by default) compute monthly decile groups
  and report the mean market_cap per decile (market-cap weighted where appropriate).
- Test whether the decile ordering shows a monotonic relationship with market cap
  (Spearman correlation between decile index and mean market cap).
- Save CSVs and PNG bar charts to output folder and print summary statistics.

Usage:
  python edgescore_mcap_analysis.py \
      --master output/master_df_monthly_panel_with_SR.csv \
      --marketcap "D:\JetBrains\pythonProject1\MST\stock_data\market_cap.csv" \
      --out output \
      --metrics EdgeScore_new NTL SR_mean

Notes:
- Master panel must include columns: date, code, market_cap (or you can pass a marketcap CSV to merge).
- The market_cap CSV expected format (as in your screenshot): first column trade_date, other columns are stock codes (wide).
  The script will melt it to long format and merge on date/code if necessary.
- Produces files in --out:
    weight_vs_mcap_{metric}.csv  (per-decile mean mcap & counts)
    weight_vs_mcap_{metric}.png  (barplot)
    group_return_ts_{metric}_mcap.csv (monthly group mean market caps time series)

Requirements:
  pandas, numpy, scipy, matplotlib, seaborn
"""

import os
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import rankdata, spearmanr

# ---------------------------
# Utilities
# ---------------------------
def winsorize_series(s: pd.Series, low_q=0.01, high_q=0.99) -> pd.Series:
    if s.dropna().empty:
        return s
    lo = s.quantile(low_q)
    hi = s.quantile(high_q)
    return s.clip(lo, hi)

def rank01_per_array(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr)
    if arr.size <= 1:
        return np.zeros_like(arr, dtype=float)
    r = rankdata(arr, method='average')  # 1..N
    return (r - 1) / (len(arr) - 1)

def assign_deciles_robust(series: pd.Series, n_groups=10) -> pd.Series:
    """
    Robust decile assignment:
      - try pd.qcut on the raw values, but if duplicates fail, use rank then cut.
    Returns integer labels 0..n_groups-1 (pandas Int64 dtype to allow NA).
    """
    try:
        labels = pd.qcut(series, q=n_groups, labels=False, duplicates='raise')
        return labels.astype(int)
    except Exception:
        r = series.rank(method='first', na_option='keep')
        try:
            bins = pd.qcut(r, q=n_groups, labels=False, duplicates='drop')
            return bins.astype('Int64')
        except Exception:
            # fallback: equal-sized by rank using cut
            bins = pd.cut(r, bins=n_groups, labels=False)
            return bins.astype('Int64')

def melt_marketcap_wide_to_long(mc_path, date_col_candidates=('trade_date','date','datetime')):
    """
    Read wide market cap csv that has first column as date (likely 'trade_date') and
    other columns as codes. Convert to long format with columns ['date','code','market_cap'].
    """
    df_wide = pd.read_csv(mc_path, header=0, dtype=str)
    # try to find the date column name by checking candidates
    cols = list(df_wide.columns)
    date_col = None
    for c in date_col_candidates:
        if c in cols:
            date_col = c
            break
    if date_col is None:
        # assume first column is date
        date_col = cols[0]
    # read again with parse_dates for date_col
    df_wide = pd.read_csv(mc_path, parse_dates=[date_col], dtype={c: float for c in cols if c!=date_col})
    df_long = df_wide.melt(id_vars=[date_col], var_name='code', value_name='market_cap')
    df_long = df_long.rename(columns={date_col: 'date'})
    # strip code whitespace and ensure string codes
    df_long['code'] = df_long['code'].astype(str).str.strip()
    # ensure numeric market_cap
    df_long['market_cap'] = pd.to_numeric(df_long['market_cap'], errors='coerce')
    return df_long

# ---------------------------
# Core analysis
# ---------------------------
def analyze_metrics_vs_mcap(master_df, metrics, out_folder, n_groups=10, winsor_q=(0.01,0.99)):
    """
    master_df must include: date (datetime), code (str), market_cap (float).
    metrics: list of column names in master_df to group by.
    """
    os.makedirs(out_folder, exist_ok=True)

    # Ensure types
    master_df = master_df.copy()
    if 'date' not in master_df.columns:
        raise ValueError("master_df must contain 'date' column")
    master_df['date'] = pd.to_datetime(master_df['date'])
    master_df['code'] = master_df['code'].astype(str)

    # For each metric, assign decile per month and compute group statistics
    summary_results = {}
    for metric in metrics:
        if metric not in master_df.columns:
            print(f"Metric '{metric}' not in master dataframe. Skipping.")
            continue
        print(f"\nProcessing metric: {metric}")

        df = master_df[['date','code','market_cap','fwd_ret']].copy()
        df[metric] = master_df[metric].copy()

        # per-month winsorize + rank01 if numeric
        def process_month(g):
            g = g.copy()
            if g[metric].notna().sum() == 0:
                g['r_metric'] = np.nan
                return g
            g[metric] = pd.to_numeric(g[metric], errors='coerce')
            g[metric+'_w'] = winsorize_series(g[metric], *winsor_q)
            g['r_metric'] = rank01_per_array(g[metric+'_w'].values)
            return g

        df = df.groupby('date', group_keys=False).apply(process_month).reset_index(drop=True)

        # assign deciles robustly on r_metric (or on raw if r_metric NA)
        def assign_grp(s):
            # prefer ranking on r_metric where available
            if s['r_metric'].notna().sum() >= n_groups:
                return assign_deciles_robust(s['r_metric'], n_groups)
            else:
                return assign_deciles_robust(s[metric], n_groups)

        df['grp'] = df.groupby('date', group_keys=False).apply(lambda g: assign_grp(g)).reset_index(level=0, drop=True)

        # compute monthly group stats: mean market cap (mean and median), count, mean fwd_ret
        def group_weighted_mcap(g):
            v = g[g['market_cap'] > 0].copy()
            if v.empty:
                return np.nan
            # simple arithmetic mean of market_cap (not weighting by market_cap, since we examine size)
            return v['market_cap'].mean()

        grp_ts = df.groupby(['date','grp'], observed=False).agg(
            mean_mcap=('market_cap', 'mean'),
            median_mcap=('market_cap','median'),
            cnt=('code','count'),
            mean_return=('fwd_ret','mean')
        ).unstack(level=1)

        # ensure columns for all groups exist
        # Convert grp_ts to DataFrame with columns 0..n_groups-1
        # grp_ts is MultiIndex columns (metric), so extract properly
        # We'll build time series DataFrame for mean_mcap per group:
        mean_mcap_ts = grp_ts['mean_mcap'] if ('mean_mcap' in grp_ts.columns) else grp_ts.iloc[:, :n_groups]
        # Reindex columns to 0..n_groups-1
        for i in range(n_groups):
            if i not in mean_mcap_ts.columns:
                mean_mcap_ts[i] = np.nan
        mean_mcap_ts = mean_mcap_ts.reindex(columns=range(n_groups)).sort_index(axis=1)

        # compute long-run mean by group
        mean_by_group = mean_mcap_ts.mean(axis=0, skipna=True)
        # compute spearman between decile index (1..n_groups) and mean_by_group
        idx = np.arange(1, n_groups+1)
        try:
            rho, pval = spearmanr(idx, mean_by_group.values)
        except Exception:
            rho, pval = (np.nan, np.nan)

        # Save aggregated CSV
        out_csv = os.path.join(out_folder, f'weight_vs_mcap_{metric}.csv')
        # Build DataFrame for saving: mean_by_group, median_by_group, counts (averaged)
        # compute average cnt and median_mcap across months
        cnt_ts = grp_ts['cnt'] if ('cnt' in grp_ts.columns) else grp_ts.iloc[:, :n_groups]
        for i in range(n_groups):
            if i not in cnt_ts.columns:
                cnt_ts[i] = np.nan
        cnt_ts = cnt_ts.reindex(columns=range(n_groups)).sort_index(axis=1)
        median_mcap_ts = grp_ts['median_mcap'] if ('median_mcap' in grp_ts.columns) else grp_ts.iloc[:, :n_groups]
        for i in range(n_groups):
            if i not in median_mcap_ts.columns:
                median_mcap_ts[i] = np.nan
        median_mcap_ts = median_mcap_ts.reindex(columns=range(n_groups)).sort_index(axis=1)

        out_df = pd.DataFrame({
            'decile': np.arange(1, n_groups+1),
            'mean_mcap': mean_by_group.values,
            'median_mcap': median_mcap_ts.mean(axis=0, skipna=True).values,
            'avg_count': cnt_ts.mean(axis=0, skipna=True).values
        })
        out_df.to_csv(out_csv, index=False)
        print(f"Saved summary to {out_csv}")

        # Save monthly time series CSV of mean_mcap per group
        grp_ts_mean_mcap = mean_mcap_ts.copy()
        grp_ts_mean_mcap.index = pd.to_datetime(grp_ts_mean_mcap.index)
        grp_ts_mean_mcap.to_csv(os.path.join(out_folder, f'group_mcap_ts_{metric}.csv'))
        print("Saved monthly timeseries of mean mcap per group.")

        # Plot bar chart of mean_by_group
        plt.figure(figsize=(9,5))
        vals = (mean_by_group.values / 1e9)  # show in billions for readability
        labels = [f'D{i}' for i in range(1, n_groups+1)]
        sns.barplot(x=labels, y=vals, palette='viridis')
        plt.xlabel('Decile Group (D1 lowest -> D10 highest)')
        plt.ylabel('Mean Market Cap (billion)')
        plt.title(f'{metric} 分组平均市值 (均值, 单位: billion)\nSpearman(decile vs mean_mcap)={rho:.3f} (p={pval:.3g})')
        plt.tight_layout()
        outpng = os.path.join(out_folder, f'weight_vs_mcap_{metric}.png')
        plt.savefig(outpng, dpi=150)
        plt.close()
        print(f"Saved plot to {outpng}")

        # Save additional diagnostics: per-month spearman between decile index and mean mcap (distribution)
        per_month_spearman = []
        for dt, row in mean_mcap_ts.iterrows():
            try:
                arr = row.values
                if np.isnan(arr).all():
                    per_month_spearman.append(np.nan)
                    continue
                r, _ = spearmanr(idx, arr)
                per_month_spearman.append(r)
            except Exception:
                per_month_spearman.append(np.nan)
        per_month_spearman = pd.Series(per_month_spearman, index=mean_mcap_ts.index)
        per_month_spearman.to_csv(os.path.join(out_folder, f'per_month_spearman_{metric}.csv'))
        print("Saved per-month spearman series.")

        # Print summary
        print(f"Metric {metric}: overall mean mcap by decile (1..{n_groups}):")
        for i, mval in enumerate(mean_by_group.values, start=1):
            print(f" D{i}: {mval:.2f}")
        print(f"Spearman(decile vs mean_mcap) = {rho:.4f} , p = {pval:.4g}")
        summary_results[metric] = {
            'decile_mean_mcap': mean_by_group.values,
            'spearman': rho,
            'pval': pval,
            'per_month_spearman_mean': np.nanmean(per_month_spearman)
        }

    return summary_results

# ---------------------------
# CLI and I/O
# ---------------------------
def main():
    parser = argparse.ArgumentParser(description="Analyze EdgeScore/NTL/SR relationship with market cap by deciles")
    parser.add_argument('--master', type=str, default='output/master_df_monthly_panel_with_SR.csv', help='master panel csv with date,code,market_cap and metrics')
    parser.add_argument('--marketcap', type=str, default=None, help='(optional) wide market cap CSV path to merge if master market_cap missing')
    parser.add_argument('--out', type=str, default='output', help='output folder')
    parser.add_argument('--metrics', nargs='+', default=['EdgeScore_new','NTL','SR_mean'], help='metrics to use for grouping')
    parser.add_argument('--n_groups', type=int, default=10, help='number of groups/deciles')
    args = parser.parse_args()

    master_csv = args.master
    mc_csv = args.marketcap
    out_folder = args.out
    metrics = args.metrics
    n_groups = args.n_groups

    if not os.path.exists(master_csv):
        raise FileNotFoundError(f"Master CSV not found: {master_csv}")

    print("Loading master panel:", master_csv)
    master = pd.read_csv(master_csv, parse_dates=['date'], dtype={'code':str})
    # ensure code column exists
    if 'code' not in master.columns and 'index' in master.columns:
        master = master.rename(columns={'index':'code'})

    # If market_cap column not present or has many NaNs, try to merge from provided marketcap CSV
    need_merge = False
    if 'market_cap' not in master.columns:
        need_merge = True
    else:
        # check proportion of missing
        miss_frac = master['market_cap'].isna().mean()
        if miss_frac > 0.2 and mc_csv is not None:
            need_merge = True

    if need_merge:
        if mc_csv is None:
            print("market_cap missing in master and no marketcap CSV provided. Exiting.")
            return
        print("Merging market_cap from:", mc_csv)
        mcap_long = melt_marketcap_wide_to_long(mc_csv)
        # normalize column names
        mcap_long['date'] = pd.to_datetime(mcap_long['date'])
        mcap_long['code'] = mcap_long['code'].astype(str)
        # merge on date & code
        master = master.merge(mcap_long, how='left', on=['date','code'], suffixes=('','_mc'))
        # if market_cap already existed but had NaN, fill from marketcap file
        if 'market_cap' not in master.columns and 'market_cap_mc' in master.columns:
            master = master.rename(columns={'market_cap_mc':'market_cap'})
        else:
            master['market_cap'] = master['market_cap'].fillna(master.get('market_cap_mc', np.nan))
        # drop helper col if exists
        if 'market_cap_mc' in master.columns:
            master = master.drop(columns=['market_cap_mc'])

    # ensure market_cap numeric
    if 'market_cap' not in master.columns:
        raise ValueError("market_cap not found after attempted merge. Please provide a master with market_cap or a valid marketcap CSV.")
    master['market_cap'] = pd.to_numeric(master['market_cap'], errors='coerce')

    # check metrics existence
    missing_metrics = [m for m in metrics if m not in master.columns]
    if missing_metrics:
        print("Warning: some requested metrics missing in master:", missing_metrics)
        # still proceed with available ones
        metrics = [m for m in metrics if m in master.columns]
        if not metrics:
            print("No valid metrics to analyze. Exiting.")
            return

    # Run analysis
    results = analyze_metrics_vs_mcap(master, metrics, out_folder, n_groups=n_groups)

    # Save overall summary
    summary_rows = []
    for metric, info in results.items():
        summary_rows.append({
            'metric': metric,
            'spearman': info['spearman'],
            'pval': info['pval'],
            'per_month_spearman_mean': info['per_month_spearman_mean']
        })
    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(os.path.join(out_folder, 'mcap_vs_metric_summary.csv'), index=False)
        print("Saved overall summary to", os.path.join(out_folder, 'mcap_vs_metric_summary.csv'))

    print("Done.")

if __name__ == "__main__":
    main()