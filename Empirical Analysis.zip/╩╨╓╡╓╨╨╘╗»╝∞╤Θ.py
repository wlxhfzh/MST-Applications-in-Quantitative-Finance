#!/usr/bin/env python3
"""
Run diagnostics on residualized SR & NTL (master_df_residualized.csv)

Outputs to ./output_resid/:
 - decile mean return CSV + PNG for EdgeScore_resid
 - long-short timeseries CSV and LS stats printed
 - IC monthly CSV + PNG
 - Fama-MacBeth style coef CSV + printed summary
 - comparison CSV if original metrics present

Usage:
    python run_resid_check.py --master output/master_df_residualized.csv --out output_resid
"""
import os, argparse, numpy as np, pandas as pd
from scipy.stats import spearmanr, rankdata
import statsmodels.api as sm
import matplotlib.pyplot as plt

def r01_array(a):
    a = np.asarray(a)
    if a.size <= 1: return np.zeros_like(a, dtype=float)
    r = rankdata(a, method='average')
    return (r - 1) / (len(a) - 1)

def weighted_group_return(g):
    v = g[g['market_cap']>0].copy()
    if v.empty: return np.nan
    w = v['market_cap'] / v['market_cap'].sum()
    return (v['fwd_ret'] * w).sum()

def long_short_stats(ls_series, bootstrap_n=2000, seed=42):
    ls = ls_series.dropna()
    n = len(ls)
    if n==0:
        return dict(n=0, mean=np.nan, std=np.nan, t=np.nan, pos_frac=np.nan, ci=(np.nan,np.nan))
    mean = ls.mean()
    std = ls.std(ddof=1)
    t = mean / (std/np.sqrt(n)) if std>0 else np.nan
    pos_frac = (ls>0).mean()
    rng = np.random.default_rng(seed)
    arr = ls.values
    bs = [rng.choice(arr, size=len(arr), replace=True).mean() for _ in range(bootstrap_n)]
    ci = (np.percentile(bs,2.5), np.percentile(bs,97.5))
    return dict(n=n, mean=mean, std=std, t=t, pos_frac=pos_frac, ci=ci, series=ls)

def compute_decile_returns(df, score_col, n_groups=10):
    df = df.copy()
    df['r_score'] = df.groupby('date')[score_col].transform(lambda s: r01_array(s.fillna(0).values))
    df['rank_tmp'] = df.groupby('date')['r_score'].transform(lambda s: s.rank(method='first'))
    def safe_qcut(s):
        try:
            return pd.qcut(s, q=n_groups, labels=False, duplicates='drop')
        except:
            return pd.cut(s.rank(method='first'), bins=n_groups, labels=False)
    df['grp'] = df.groupby('date')['rank_tmp'].transform(lambda s: safe_qcut(s))
    grp_ts = df.groupby(['date','grp']).apply(weighted_group_return).unstack(level=1)
    # ensure columns 0..n_groups-1
    for i in range(n_groups):
        if i not in grp_ts.columns:
            grp_ts[i] = np.nan
    grp_ts = grp_ts.reindex(columns=range(n_groups))
    mean_by_group = grp_ts.mean(axis=0)
    rho, p = spearmanr(np.arange(1, n_groups+1), mean_by_group.values)
    ls_ts = (grp_ts[n_groups-1] - grp_ts[0]).dropna()
    return dict(grp_ts=grp_ts, mean_by_group=mean_by_group, spearman=(rho,p), ls_ts=ls_ts, df_with_groups=df)

def fama_macbeth(master_df, xcols, ycol='fwd_ret', min_obs=30):
    # monthly cross-sectional regressions, collect coefficients
    rows=[]
    for dt, g in master_df.groupby('date'):
        g2 = g.dropna(subset=xcols+[ycol])
        if len(g2) < min_obs: continue
        X = sm.add_constant(g2[xcols])
        y = g2[ycol]
        try:
            r = sm.OLS(y, X).fit()
            rows.append(r.params)
        except:
            continue
    if not rows:
        return pd.DataFrame()
    dfcoefs = pd.DataFrame(rows)
    summary = pd.DataFrame({
        'coef_mean': dfcoefs.mean(),
        'coef_std': dfcoefs.std(ddof=1),
        't_approx': dfcoefs.mean() / (dfcoefs.std(ddof=1)/np.sqrt(len(dfcoefs)))
    })
    return dfcoefs, summary

def plot_bar_mean_by_group(mean_by_group, outpng, ylabel='Mean Monthly Return (%)', title=''):
    vals = mean_by_group.values * 100  # percent
    labels = [f'D{i}' for i in range(1, len(vals)+1)]
    plt.figure(figsize=(9,5))
    plt.bar(labels, vals, color=plt.cm.viridis(np.linspace(0,1,len(vals))))
    plt.ylabel(ylabel); plt.xlabel('Decile Group (D1 lowest -> D10 highest)')
    plt.title(title); plt.grid(axis='y', linestyle='--', alpha=0.4)
    plt.tight_layout(); plt.savefig(outpng, dpi=150); plt.close()

def plot_ic(ic_series, outpng, title='IC (Spearman)'):
    plt.figure(figsize=(10,3)); plt.plot(ic_series.index, ic_series.values, marker='.', linewidth=0.8)
    plt.axhline(0, color='k', linestyle='--', alpha=0.6)
    plt.title(title); plt.tight_layout(); plt.savefig(outpng, dpi=150); plt.close()

def main(master_path, out_folder, w_ntl=0.6, w_sr=0.4):
    os.makedirs(out_folder, exist_ok=True)
    m = pd.read_csv(master_path, parse_dates=['date'])
    # required cols check
    for c in ['date','code','market_cap','fwd_ret']:
        if c not in m.columns:
            raise ValueError(f"master missing column: {c}")
    # prefer residual cols
    if 'SR_resid' in m.columns and 'NTL_resid' in m.columns:
        sr_col='SR_resid'; ntl_col='NTL_resid'
    elif 'SR_resid' in m.columns and 'NTL' in m.columns:
        sr_col='SR_resid'; ntl_col='NTL'
    else:
        # fallback to SR_mean & NTL (but user said file is residualized)
        sr_col='SR_mean'; ntl_col='NTL'

    print("Using columns:", sr_col, ntl_col)
    # build EdgeScore_resid
    m['EdgeScore_resid'] = w_ntl * m[ntl_col].fillna(0) + w_sr * m[sr_col].fillna(0)

    # 1) decile analysis on EdgeScore_resid
    res = compute_decile_returns(m, score_col='EdgeScore_resid', n_groups=10)
    grp_ts = res['grp_ts']; mean_by_group = res['mean_by_group']; rho,p = res['spearman']; ls_ts = res['ls_ts']
    print("EdgeScore_resid Spearman(decile vs mean_return) = %.4f (p=%.3g)" % (rho,p))
    ls_stats = long_short_stats(ls_ts)
    print("EdgeScore_resid LS stats:", ls_stats)
    # save
    grp_ts.to_csv(os.path.join(out_folder, 'grp_ts_edgescore_resid.csv'))
    mean_by_group.to_csv(os.path.join(out_folder, 'mean_by_group_edgescore_resid.csv'), header=['mean_return'])
    plot_bar_mean_by_group(mean_by_group, os.path.join(out_folder, 'edgescore_resid_decile_mean_return.png'),
                           title=f'EdgeScore_resid 分组平均月度收益\nSpearman={rho:.3f} (p={p:.3g})')

    # 2) IC time series for EdgeScore_resid
    ics=[]
    for dt,g in m.groupby('date'):
        g2 = g.dropna(subset=['EdgeScore_resid','fwd_ret'])
        if len(g2)<20:
            ics.append(np.nan); continue
        r,_ = spearmanr(g2['EdgeScore_resid'], g2['fwd_ret'])
        ics.append(r)
    ic_series=pd.Series(ics, index=sorted(m['date'].unique()))
    ic_series.to_csv(os.path.join(out_folder, 'edgescore_resid_ic_monthly.csv'))
    plot_ic(ic_series, os.path.join(out_folder, 'edgescore_resid_ic_monthly.png'))

    # 3) Fama-MacBeth style: fwd_ret ~ NTL_resid + SR_resid + interaction (monthly)
    if 'SR_resid' in m.columns and 'NTL_resid' in m.columns:
        dfcoefs, summary = fama_macbeth(m, xcols=['NTL_resid','SR_resid', ], ycol='fwd_ret')
        # add interaction by recomputing per-month with interaction
        rows=[]
        for dt,g in m.groupby('date'):
            g2=g.dropna(subset=['fwd_ret','SR_resid','NTL_resid'])
            if len(g2)<30: continue
            Xg = sm.add_constant(pd.DataFrame({
                'NTL_resid': g2['NTL_resid'],
                'SR_resid': g2['SR_resid'],
                'NTLxSR_resid': g2['NTL_resid']*g2['SR_resid']
            }))
            try:
                rg = sm.OLS(g2['fwd_ret'], Xg).fit()
                rows.append(rg.params)
            except:
                continue
        if rows:
            dfcoefs_int = pd.DataFrame(rows)
            summary_int = pd.DataFrame({
                'coef_mean': dfcoefs_int.mean(),
                'coef_std': dfcoefs_int.std(ddof=1),
                't_approx': dfcoefs_int.mean() / (dfcoefs_int.std(ddof=1)/np.sqrt(len(dfcoefs_int)))
            })
            dfcoefs_int.to_csv(os.path.join(out_folder, 'fmb_monthly_coefs_interaction.csv'))
            summary_int.to_csv(os.path.join(out_folder, 'fmb_summary_interaction.csv'))
            print("FMB interaction summary:\n", summary_int)
        else:
            print("Not enough monthly observations for interaction FMB.")
    else:
        print("Residual columns not found for FMB interaction test. Skipping.")

    # 4) Compare to original (if present)
    if 'EdgeScore_new' in m.columns:
        # compute orig groups & LS
        orig = compute_decile_returns(m, score_col='EdgeScore_new', n_groups=10)
        orig_ls = long_short_stats(orig['ls_ts'])
        print("Original EdgeScore LS mean/t:", orig_ls['mean'], orig_ls['t'])
        # save comparison
        comp = pd.DataFrame({
            'edgescore_orig_mean_by_group': orig['mean_by_group'].values,
            'edgescore_resid_mean_by_group': mean_by_group.values
        }, index=[f'D{i}' for i in range(1,11)])
        comp.to_csv(os.path.join(out_folder, 'compare_orig_vs_resid.csv'))
        print("Saved compare_orig_vs_resid.csv")

    # 5) Save LS timeseries
    ls_ts.to_csv(os.path.join(out_folder, 'ls_ts_edgescore_resid.csv'))
    print("All outputs saved to", out_folder)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--master', default='output/master_df_residualized.csv')
    parser.add_argument('--out', default='output_resid')
    parser.add_argument('--w_ntl', type=float, default=0.6)
    parser.add_argument('--w_sr', type=float, default=0.4)
    args = parser.parse_args()
    main(args.master, args.out, w_ntl=args.w_ntl, w_sr=args.w_sr)