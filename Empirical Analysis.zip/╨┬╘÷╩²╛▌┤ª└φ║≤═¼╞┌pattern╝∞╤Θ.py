import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import logging, datetime
from tqdm import tqdm
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
from statsmodels.stats import sandwich_covariance as sw
from scipy.stats.mstats import winsorize
from sklearn.preprocessing import StandardScaler
from typing import Union

# ----------------- 基本配置 -----------------
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
MARKET_CAP_FILE = 'stock_data/market_cap.csv'
OUTPUT_FOLDER = 'output'
NUM_GROUPS = 10
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

log_filename = f"EdgeScore_Robustness_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler(os.path.join(OUTPUT_FOLDER, log_filename), 'w', 'utf-8'),
                              logging.StreamHandler()])
logger = logging.getLogger(__name__)

try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception:
    pass

# ----------------- 数据加载与预处理 -----------------
logger.info("加载价格数据和市值数据...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
df_prices.columns = df_prices.columns.astype(str)

df_cap = pd.read_csv(MARKET_CAP_FILE, index_col=0, parse_dates=True)
df_cap.columns = df_cap.columns.astype(str)

# 限制区间（可选）
df_prices = df_prices.loc['2019-01-01':'2022-12-31']
df_cap = df_cap.loc['2019-01-01':'2022-12-31']

logger.info("检查数据中是否存在 NaN 或常数列...")
df_prices = df_prices.dropna(axis=1, how='all')  # 删除全为 NaN 的列
df_prices = df_prices.loc[:, (df_prices != 0).any(axis=0)]  # 删除全为零的列
df_prices = df_prices.fillna(df_prices.mean())  # 用均值填充 NaN

df_cap = df_cap.dropna(axis=1, how='all')  # 删除全为 NaN 的列
df_cap = df_cap.loc[:, (df_cap != 0).any(axis=0)]  # 删除全为零的列
df_cap = df_cap.fillna(df_cap.mean())  # 用均值填充 NaN

logger.info("对数据进行去极值处理...")
df_prices = df_prices.apply(lambda x: winsorize(x, limits=(0.01, 0.01)), axis=0)
df_cap = df_cap.apply(lambda x: winsorize(x, limits=(0.01, 0.01)), axis=0)

logger.info("对数据进行标准化处理...")
scaler = StandardScaler()
df_prices = pd.DataFrame(scaler.fit_transform(df_prices), index=df_prices.index, columns=df_prices.columns)
df_cap = pd.DataFrame(scaler.fit_transform(df_cap), index=df_cap.index, columns=df_cap.columns)

# ----------------- EdgeScore 计算 -----------------
def calculate_edgescore_metrics(price_window: pd.DataFrame) -> Union[pd.Series, None]:
    stock_codes = price_window.columns.astype(str)
    rets = price_window.pct_change().dropna()
    if rets.shape[0] < 10 or len(stock_codes) < 2:
        return None
    corr = rets.corr().fillna(0)
    dist = np.sqrt(2 * (1 - corr))
    mst = minimum_spanning_tree(dist)
    G = nx.from_scipy_sparse_array(mst)
    G = nx.relabel_nodes(G, {i: code for i, code in enumerate(stock_codes)})
    if len(G) == 0:
        return None

    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        ntl = dict(nx.single_source_shortest_path_length(G, root))
    except ValueError:
        ntl = {n: 0 for n in G.nodes()}
    nd = dict(G.degree())
    bc = nx.betweenness_centrality(G, weight='weight')

    df = pd.DataFrame({'NTL': pd.Series(ntl), 'ND': pd.Series(nd), 'BC': pd.Series(bc)}).fillna(0)

    edgescore = (
        df['NTL'].rank(pct=True) * 1.0 +  # 提高 NTL 权重
        (1 - df['ND'].rank(pct=True)) * -0.2 +  # 降低 ND 权重
        (1 - df['BC'].rank(pct=True)) * -0.1    # 降低 BC 权重
    )
    edgescore.name = 'EdgeScore'
    return edgescore

# ----------------- 月内分组与收益 -----------------
monthly_groups = df_prices.groupby(pd.Grouper(freq='MS'))

records = []
logger.info("逐月计算 EdgeScore、合并当月收益与市值并分组...")
for month_start, price_win in tqdm(monthly_groups):
    if price_win.shape[0] < 2:
        continue
    es = calculate_edgescore_metrics(price_win)
    if es is None:
        continue

    month_end = month_start.to_period('M').to_timestamp('M')
    try:
        p0 = df_prices.loc[df_prices.index.asof(month_start)]
        p1 = df_prices.loc[df_prices.index.asof(month_end)]
    except KeyError:
        continue
    r = (p1 / p0 - 1).rename('ret')

    mcap = df_cap.loc[df_cap.index.asof(month_start)].rename('mcap')

    dfm = pd.concat([es, r, mcap], axis=1).dropna()
    if dfm.empty:
        continue

    dfm = dfm.sort_values('EdgeScore', ascending=False)

    ranked = dfm['EdgeScore'].rank(method='first')
    group_size = len(dfm) / NUM_GROUPS
    dfm['group'] = np.ceil(ranked / group_size).astype(int).clip(1, NUM_GROUPS)
    dfm['group'] = dfm['group'].map(lambda g: f'D{g}')

    def _gw(d):
        d = d[d['mcap'] > 0]
        if d.empty:
            return np.nan
        w = d['mcap'] / d['mcap'].sum()
        return np.dot(w, d['ret'])

    gret = dfm.groupby('group', observed=False).apply(_gw).rename('group_ret')
    if gret.isna().all():
        continue

    for g, v in gret.items():
        records.append({'date': month_start, 'year': month_start.year, 'group': g, 'group_ret': v})

panel = pd.DataFrame(records)
if panel.empty:
    raise SystemExit("无有效样本；请检查数据。")

# ----------------- 年度单调性与图表输出 -----------------
panel['g_rank'] = panel['group'].str.extract(r'D(\d+)').astype(int)

def _monotonicity_year(dfy: pd.DataFrame):
    slopes = []
    for d, ddf in dfy.groupby('date'):
        x = add_constant(ddf['g_rank'].values)
        y = ddf['group_ret'].values
        try:
            beta = OLS(y, x, missing='drop').fit().params[-1]
            slopes.append(beta)
        except Exception:
            continue
    slopes = pd.Series(slopes)
    X = np.ones((len(slopes), 1))
    fit = OLS(slopes.values, X).fit()

    # 修改：移除 maxlags 参数
    cov = sw.cov_hac(fit)  # 使用 cov_hac，不传递 maxlags 参数
    t = fit.params[0] / np.sqrt(cov[0, 0])
    return pd.Series({'mono_slope_mean': slopes.mean(), 'mono_t': t})

year_stats = panel.groupby('year').apply(_monotonicity_year).reset_index()

plt.figure(figsize=(8, 4))
sns.barplot(x=year_stats['year'], y=year_stats['mono_slope_mean'], color='#4472c4')
for i, row in year_stats.iterrows():
    plt.text(i, row['mono_slope_mean'], f"t={row['mono_t']:.2f}", ha='center', va='bottom', fontsize=9)
plt.title('年度单调性斜率及 t 值')
plt.ylabel('斜率均值')
plt.xlabel('年份')
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_FOLDER, 'edgescore_yearly_mono_t.png'), dpi=150)

year_stats.to_csv(os.path.join(OUTPUT_FOLDER, 'edgescore_year_stats.csv'), index=False)
logger.info
