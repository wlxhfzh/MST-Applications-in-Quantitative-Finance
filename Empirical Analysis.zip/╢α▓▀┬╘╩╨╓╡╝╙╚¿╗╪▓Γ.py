import pandas as pd
import numpy as np
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx
from tqdm import tqdm
import os
import matplotlib.pyplot as plt
from typing import List, Dict, Any

# ========== 0. 全局配置 & 回测参数 (【总控制台】) ==========
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
STOCK_LIST_FILE = 'stock_data/index_stocks_list.csv'
HS300_FILE = 'stock_data/HS300_monthly_return.csv'
OUTPUT_FOLDER = 'output'
MST_METRICS_CACHE_FILE = 'mst_metrics_cache_final.parquet'
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# --- 总控制台 ---
CONFIG = {
    # --- 策略开关 ---
    "STRATEGIES": {
        '做多边缘': True,
        '做多核心': True,
        '多边缘-空核心': True,
        '多核心-空边缘': True,
        '做多边缘和核心': True,
        '做空边缘和核心': True,
    },

    # --- 过滤器开关 ---
    'USE_MOMENTUM_FILTER': False,
    'USE_VOLATILITY_FILTER': False,

    # --- 基础回测参数 ---
    'INITIAL_CAPITAL': 1_000_000,
    'TOP_N_STOCKS': 20,
    'COMMISSION_RATE': 0.001,
    'SLIPPAGE_RATE': 0.0005,
    'STAMP_DUTY_RATE': 0.001,  # 卖出时收取
    'VOLATILITY_LOOKBACK': 126,
    'MOMENTUM_LOOKBACK': 63,
    'VOLATILITY_CUTOFF': 0.8,
}

# 中文字体配置
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception:
    print("SimHei 字体未找到。")

# ========== 1. 数据准备 (不变) ==========
print("数据准备...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
daily_returns = df_prices.pct_change()
monthly_open = df_prices.resample('MS').first()
monthly_close = df_prices.resample('MS').last()

# ========== 2. MST指标计算函数 (不变) ==========
def calculate_mst_metrics(price_window: pd.DataFrame) -> pd.DataFrame:
    returns = price_window.pct_change().dropna()
    if len(returns) < 2 or len(returns.columns) < 2:
        return pd.DataFrame()
    corr = returns.corr().fillna(0)
    dist = np.sqrt(2 * (1 - corr))
    mst_sparse = minimum_spanning_tree(dist)
    G = nx.from_scipy_sparse_array(mst_sparse)
    node_mapping = {i: code for i, code in enumerate(corr.columns)}
    G = nx.relabel_nodes(G, node_mapping)
    if len(G.nodes) == 0:
        return pd.DataFrame()
    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except ValueError:
        levels = {node: 0 for node in G.nodes()}
    degs = dict(G.degree())
    bc = nx.betweenness_centrality(G, weight='weight')
    return pd.DataFrame({
        '股票代码': list(G.nodes()),
        'NTL': [levels.get(n, 0) for n in G.nodes()],
        'ND': [degs.get(n, 0) for n in G.nodes()],
        'BC': [bc.get(n, 0) for n in G.nodes()],
    })

# ========== 3. 生成或加载每月选股信号 (不变) ==========
if os.path.exists(MST_METRICS_CACHE_FILE):
    print(f"加载缓存文件: '{MST_METRICS_CACHE_FILE}'...")
    signals_df = pd.read_parquet(MST_METRICS_CACHE_FILE)
    print("指标加载完毕。")
else:
    print(f"未找到缓存文件。正在生成所有指标...")
    all_monthly_scores = []
    max_lookback = max(CONFIG['VOLATILITY_LOOKBACK'], CONFIG['MOMENTUM_LOOKBACK'])
    first_valid_date = df_prices.index[0] + pd.DateOffset(days=max_lookback)
    monthly_groups = df_prices[df_prices.index >= first_valid_date].groupby(pd.Grouper(freq='MS'))
    for period_start, price_window in tqdm(monthly_groups, desc="计算所有指标"):
        if len(price_window) < 20:
            continue
        metrics_df = calculate_mst_metrics(price_window)
        if metrics_df.empty:
            continue
        momentum_start = period_start - pd.DateOffset(days=CONFIG['MOMENTUM_LOOKBACK'])
        vol_start = period_start - pd.DateOffset(days=CONFIG['VOLATILITY_LOOKBACK'])
        momentum_end_price = price_window.iloc[-1]
        momentum_start_price = df_prices.loc[momentum_start:period_start].iloc[0]
        momentum = (momentum_end_price / momentum_start_price) - 1
        volatility = daily_returns.loc[vol_start:period_start].std() * np.sqrt(252)
        metrics_df['momentum'] = metrics_df['股票代码'].map(momentum)
        metrics_df['volatility'] = metrics_df['股票代码'].map(volatility)
        metrics_df['NTL_rank'] = metrics_df['NTL'].rank(pct=True)
        metrics_df['ND_rank'] = metrics_df['ND'].rank(pct=True)
        metrics_df['BC_rank'] = metrics_df['BC'].rank(pct=True)
        metrics_df['EdgeScore'] = metrics_df['NTL_rank'] + (1 - metrics_df['ND_rank']) + (1 - metrics_df['BC_rank'])
        metrics_df['月份'] = period_start
        all_monthly_scores.append(metrics_df)
    signals_df = pd.concat(all_monthly_scores).reset_index(drop=True)
    signals_df['生效月份'] = signals_df.groupby('股票代码')['月份'].shift(-1)
    signals_df = signals_df.dropna(subset=['生效月份'])
    signals_df.to_parquet(MST_METRICS_CACHE_FILE)
    print(f"缓存文件 '{MST_METRICS_CACHE_FILE}' 已保存。")

# ========== 工具函数：按“市值”计算权重（此处用开盘价作为权重代理） ==========
def cap_weights(price_series: pd.Series, stocks: List[str]) -> Dict[str, float]:
    valid = [s for s in stocks if s in price_series.index and pd.notna(price_series[s]) and price_series[s] > 0]
    if not valid:
        return {}
    vals = np.array([price_series[s] for s in valid], dtype=float)
    total = float(np.sum(vals))
    if total <= 0:
        return {}
    return {s: float(price_series[s]) / total for s in valid}

# ========== 4. 核心回测引擎（仅把等权重改成市值加权；其他逻辑不动） ==========
def run_backtest(strategy_name: str, signals_df: pd.DataFrame, rebalance_dates: List[pd.Timestamp],
                 config: Dict[str, Any]) -> pd.DataFrame:
    print(f"--- 开始回测策略: {strategy_name} ---")
    is_long_short = '空' in strategy_name

    portfolio_history = [{'日期': rebalance_dates[0] - pd.DateOffset(days=1), '净值': 1.0}]

    if is_long_short:
        # 多空策略：与原逻辑一致，只有权重从等权改为市值加权
        long_positions, short_positions = {}, {}
        long_open_prices, short_open_prices = {}, {}

        for i, date in enumerate(tqdm(rebalance_dates, desc=strategy_name)):
            if date not in monthly_open.index:
                continue

            # 先对上一个持仓结算当月收益（按原逻辑）
            if i > 0:
                last_rebalance_date = rebalance_dates[i - 1]
                if last_rebalance_date in monthly_close.index:
                    eom_prices = monthly_close.loc[last_rebalance_date]
                    pnl = 0.0
                    for stock, shares in long_positions.items():
                        if stock in eom_prices and not pd.isna(eom_prices[stock]):
                            pnl += shares * (eom_prices[stock] - long_open_prices[stock])
                    for stock, shares in short_positions.items():
                        if stock in eom_prices and not pd.isna(eom_prices[stock]):
                            pnl -= shares * (eom_prices[stock] - short_open_prices[stock])
                    monthly_return = pnl / config['INITIAL_CAPITAL']
                    portfolio_history.append({'日期': eom_prices.name,
                                              '净值': portfolio_history[-1]['净值'] * (1 + monthly_return)})

            # 月初调仓
            long_positions.clear(); short_positions.clear()
            long_open_prices.clear(); short_open_prices.clear()
            open_prices = monthly_open.loc[date]

            long_candidates = signals_df[signals_df['生效月份'] == date].copy()
            short_candidates = long_candidates.copy()

            if config['USE_MOMENTUM_FILTER']:
                long_candidates = long_candidates[long_candidates['momentum'] > 0]
                short_candidates = short_candidates[short_candidates['momentum'] < 0]
            if config['USE_VOLATILITY_FILTER'] and not long_candidates.empty:
                vol_cutoff = long_candidates['volatility'].quantile(config['VOLATILITY_CUTOFF'])
                long_candidates = long_candidates[long_candidates['volatility'] < vol_cutoff]

            if strategy_name == '多边缘-空核心':
                long_targets = long_candidates.nlargest(config['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
                short_targets = short_candidates.nsmallest(config['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
            elif strategy_name == '多核心-空边缘':
                long_targets = long_candidates.nsmallest(config['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
                short_targets = short_candidates.nlargest(config['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
            elif strategy_name == '做空边缘和核心':
                long_targets = []
                short_targets = pd.concat([
                    short_candidates.nlargest(config['TOP_N_STOCKS'], 'EdgeScore'),
                    short_candidates.nsmallest(config['TOP_N_STOCKS'], 'EdgeScore')
                ])['股票代码'].unique().tolist()
            else:
                long_targets, short_targets = [], []

            # 市值加权分配（使用开盘价作为权重代理）
            if long_targets:
                w = cap_weights(open_prices, long_targets)
                total_capital_side = config['INITIAL_CAPITAL']  # 保持原逻辑：多头名义100%资金
                for stock, weight in w.items():
                    px = open_prices[stock]
                    if px > 0:
                        long_positions[stock] = (total_capital_side * weight) / px
                        long_open_prices[stock] = px
            if short_targets:
                w = cap_weights(open_prices, short_targets)
                total_capital_side = config['INITIAL_CAPITAL']  # 保持原逻辑：空头名义100%资金
                for stock, weight in w.items():
                    px = open_prices[stock]
                    if px > 0:
                        short_positions[stock] = (total_capital_side * weight) / px
                        short_open_prices[stock] = px

    else:
        # 单边策略：原先等权 -> 改为市值加权；买入在月初开盘，卖出在下一次月初开盘（含交易成本）
        cash = config['INITIAL_CAPITAL']
        positions: Dict[str, float] = {}

        for date in tqdm(rebalance_dates, desc=strategy_name):
            if date not in monthly_open.index:
                continue

            trade_prices = monthly_open.loc[date]

            # 先卖出上月持仓（在月初开盘价），按原成本模型收取滑点与手续费及印花税
            if positions:
                for stock, shares in list(positions.items()):
                    if stock in trade_prices and not pd.isna(trade_prices[stock]):
                        sell_price = trade_prices[stock] * (1 - CONFIG['SLIPPAGE_RATE'])
                        cash += shares * sell_price * (1 - CONFIG['COMMISSION_RATE'] - CONFIG['STAMP_DUTY_RATE'])
                positions.clear()

            # 选股
            candidates = signals_df[signals_df['生效月份'] == date].copy()
            if CONFIG['USE_MOMENTUM_FILTER']:
                candidates = candidates[candidates['momentum'] > 0]
            if CONFIG['USE_VOLATILITY_FILTER'] and not candidates.empty:
                vol_cutoff = candidates['volatility'].quantile(CONFIG['VOLATILITY_CUTOFF'])
                candidates = candidates[candidates['volatility'] < vol_cutoff]

            if strategy_name == '做多边缘':
                target_stocks = candidates.nlargest(CONFIG['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
            elif strategy_name == '做多核心':
                target_stocks = candidates.nsmallest(CONFIG['TOP_N_STOCKS'], 'EdgeScore')['股票代码'].tolist()
            elif strategy_name == '做多边缘和核心':
                target_stocks = pd.concat([
                    candidates.nlargest(CONFIG['TOP_N_STOCKS'], 'EdgeScore'),
                    candidates.nsmallest(CONFIG['TOP_N_STOCKS'], 'EdgeScore')
                ])['股票代码'].unique().tolist()
            else:
                target_stocks = []

            # 市值加权买入（开盘成交，计入滑点和佣金；分配以本次可用资金为基准）
            if target_stocks:
                weights = cap_weights(trade_prices, target_stocks)
                capital_this_rebalance = cash  # 固定基数，避免循环中被递减导致权重失真
                allocated = 0.0
                for stock, weight in weights.items():
                    px = trade_prices[stock]
                    if not (px > 0):
                        continue
                    allocation = capital_this_rebalance * weight
                    buy_price = px * (1 + CONFIG['SLIPPAGE_RATE'])
                    shares = allocation / (buy_price * (1 + CONFIG['COMMISSION_RATE']))
                    if shares > 0:
                        positions[stock] = shares
                        allocated += allocation
                cash -= allocated  # 与原逻辑一致：扣除名义配置金额（手续费体现在持仓股数里）

            # 记录月末净值（使用当月月末收盘）
            if date in monthly_close.index:
                eom_prices = monthly_close.loc[date]
                portfolio_value = cash + sum(shares * eom_prices.get(stock, 0.0) for stock, shares in positions.items())
                portfolio_history.append({'日期': date, '净值': portfolio_value / CONFIG['INITIAL_CAPITAL']})

    df_result = pd.DataFrame(portfolio_history).set_index('日期').sort_index()
    df_result['净值'] = df_result['净值'].ffill()
    return df_result

# ========== 5. 综合分析与可视化 (不变) ==========
def analyze_and_plot(all_results: Dict[str, pd.DataFrame], hs300_net_value: pd.DataFrame):
    print("\n\n" + "=" * 20 + " 绩效总览 " + "=" * 20)
    plt.figure(figsize=(20, 10))

    for name, df_result in all_results.items():
        plt.plot(df_result.index, df_result['净值'], label=name, lw=1.5 if '多' in name and '空' not in name else 2.0)
        returns = df_result['净值'].resample('MS').last().pct_change().dropna()
        if not returns.empty:
            annual_return = (1 + returns).prod() ** (12 / len(returns)) - 1
            annual_volatility = returns.std() * np.sqrt(12)
            sharpe_ratio = annual_return / annual_volatility if annual_volatility != 0 else 0
            cumulative_max = df_result['净值'].cummax()
            max_drawdown = ((df_result['净值'] / cumulative_max) - 1).min()
            print(f"\n--- {name} ---")
            print(f"  年化收益率: {annual_return:.2%}, 夏普比率: {sharpe_ratio:.2f}, 最大回撤: {max_drawdown:.2%}")

    if hs300_net_value is not None:
        plt.plot(hs300_net_value.index, hs300_net_value, label='沪深300基准', linestyle='--', color='grey', lw=2)

    plt.title('几种策略对比(等权重)', fontsize=20)
    plt.xlabel('日期', fontsize=14)
    plt.ylabel('累计净值', fontsize=14)
    plt.legend(fontsize=12, bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout(rect=[0, 0, 0.85, 1])
    plt.savefig(os.path.join(OUTPUT_FOLDER, '几种策略对比(等权重）.png'))
    #plt.show()

# ========== Main Execution ==========
if __name__ == '__main__':
    strategies_to_run = [name for name, should_run in CONFIG['STRATEGIES'].items() if should_run]

    if not strategies_to_run:
        print("错误：没有在CONFIG中选择任何要运行的策略。")
    else:
        rebalance_dates = sorted([d for d in signals_df['生效月份'].unique() if pd.notna(d)])
        all_results: Dict[str, pd.DataFrame] = {}

        for strategy_name in strategies_to_run:
            df_result = run_backtest(strategy_name, signals_df, rebalance_dates, CONFIG)
            all_results[strategy_name] = df_result

        # 处理基准（可选）
        try:
            hs300_all = pd.read_csv(HS300_FILE, parse_dates=['月份'], index_col='月份')
            hs300_sliced = hs300_all.loc[rebalance_dates[0]:].copy()
            hs300_sliced.iloc[0, hs300_sliced.columns.get_loc('沪深300收益率')] = 0.0
            hs300_net_value = (1 + hs300_sliced['沪深300收益率']).cumprod()
        except Exception:
            hs300_net_value = None
            print("警告: 基准数据处理失败。")

        analyze_and_plot(all_results, hs300_net_value)