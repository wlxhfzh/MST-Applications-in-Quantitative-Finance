"""
Modified monthly EdgeScore analysis script with SR_mean included.

Changes:
- calculate_edgescore_metrics now computes SR and SR_mean (node strength and mean neighbor similarity).
- build_edgescore_new now processes SR_mean (winsorize + rank) and includes it in the EdgeScore_new composition.
- Default EDGE_WEIGHTS now includes 'SR_mean': -0.3 (tune or auto-estimate).
- Outputs include group returns and diagnostics as before.
"""
import os
import logging
import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.stats import rankdata
import networkx as nx

# ---------------------------
# Config
# ---------------------------
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
MARKET_CAP_FILE = 'stock_data/market_cap.csv'
OUTPUT_FOLDER = 'output'
NUM_GROUPS = 10
FACTOR_LOOKBACK_DAYS = 21
WINSOR_Q = (0.01, 0.99)
BC_LOG_EPS = 1e-6
# Default weights: NTL large positive, ND/BC negative (as before), SR_mean default small magnitude.
EDGE_WEIGHTS = {"NTL": 0.6, "ND": -0.1, "BC": 0, "SR_mean": 0.4}

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
log_filename = f"EdgeScore_Monthly_analysis_SR_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log"
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    handlers=[logging.FileHandler(os.path.join(OUTPUT_FOLDER, log_filename), mode='w', encoding='utf-8'),
                              logging.StreamHandler()])
logger = logging.getLogger(__name__)

# Try set Chinese fonts if available
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception:
    pass

# ---------------------------
# Utility functions
# ---------------------------
def winsorize_series(s: pd.Series, low_q=0.01, high_q=0.99) -> pd.Series:
    lo = s.quantile(low_q)
    hi = s.quantile(high_q)
    return s.clip(lo, hi)

def rank01(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr)
    if arr.size <= 1:
        return np.zeros_like(arr, dtype=float)
    r = rankdata(arr, method='average')  # 1..N
    return (r - 1) / (len(arr) - 1)

def assign_deciles_robust(series: pd.Series, n_groups=10) -> pd.Series:
    try:
        labels = pd.qcut(series, q=n_groups, labels=False, duplicates='raise')
        return labels.astype(int)
    except Exception:
        r = series.rank(method='first')
        bins = pd.cut(r, bins=n_groups, labels=False)
        return bins.astype(float).astype('Int64')

# ---------------------------
# Core network + factor calc (with SR)
# ---------------------------
def calculate_edgescore_metrics(price_window: pd.DataFrame) -> pd.DataFrame:
    """
    Build MST and compute NTL, ND, BC (raw), SR, SR_mean.
    SR definition: for MST edges with distance d, sim = 1/(1+d); SR(node) = sum(sim over neighbors);
    SR_mean = SR / degree (average neighbor similarity).
    Returns DataFrame indexed by stock code with cols ['NTL','ND','BC','SR','SR_mean','EdgeScore_raw'].
    """
    stock_codes = price_window.columns.astype(str)
    if price_window.shape[0] < 3 or len(stock_codes) < 2:
        return None

    returns = price_window.pct_change().dropna(how='all')
    if returns.shape[0] < 2:
        return None
    corr = returns.corr().fillna(0)
    dist = np.sqrt(np.clip(2 * (1 - corr.values), 0, None))
    try:
        mst_sparse = minimum_spanning_tree(dist)
        G = nx.from_scipy_sparse_array(mst_sparse)
    except Exception as e:
        logger.debug(f"MST construction failed: {e}")
        return None

    node_mapping = {i: code for i, code in enumerate(stock_codes)}
    try:
        G = nx.relabel_nodes(G, node_mapping)
    except Exception:
        pass

    if len(G.nodes) == 0:
        return None

    # root as node with max degree
    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except Exception:
        levels = {node: 0 for node in G.nodes()}

    degs = dict(G.degree())
    try:
        bc = nx.betweenness_centrality(G, weight='weight')
    except Exception:
        bc = {n: 0.0 for n in G.nodes()}

    # compute similarity on MST edges: sim = 1/(1+d)
    sims = {}
    dist_vals = []
    for u, v, data in G.edges(data=True):
        d = float(data.get('weight', 0.0))
        dist_vals.append(d)
    dmax = max(dist_vals) if len(dist_vals) > 0 else 1.0
    for u, v, data in G.edges(data=True):
        d = float(data.get('weight', 0.0))
        sim = 1.0 / (1.0 + d)
        sims[(u, v)] = sim
        sims[(v, u)] = sim

    # node SR and SR_mean
    sr = {}
    sr_mean = {}
    for node in G.nodes():
        neighs = list(G.adj[node])
        if len(neighs) == 0:
            sr[node] = 0.0
            sr_mean[node] = 0.0
        else:
            ssum = sum(sims.get((node, nb), 0.0) for nb in neighs)
            sr[node] = ssum
            sr_mean[node] = ssum / len(neighs)

    # assemble df
    df = pd.DataFrame(index=list(G.nodes()))
    df['NTL'] = pd.Series(levels)
    df['ND'] = pd.Series(degs)
    df['BC'] = pd.Series(bc)
    df['SR'] = pd.Series(sr)
    df['SR_mean'] = pd.Series(sr_mean)
    df = df.fillna(0)

    # raw EdgeScore (for comparison)
    df['EdgeScore_raw'] = (df['NTL'] * EDGE_WEIGHTS['NTL'] +
                           df['ND'] * EDGE_WEIGHTS['ND'] +
                           df['BC'] * EDGE_WEIGHTS['BC'])
    return df

# ---------------------------
# Robust EdgeScore builder (new) with SR_mean
# ---------------------------
def build_edgescore_new(factor_df: pd.DataFrame, weights=None, winsor_q=WINSOR_Q, bc_log_eps=BC_LOG_EPS):
    """
    Input: factor_df indexed by code with columns ['NTL','ND','BC','SR_mean']
    Output: edgescore_new (Series indexed by code, rank-normalized to [0,1]), and diagnostics dict.
    """
    if weights is None:
        weights = EDGE_WEIGHTS
    df = factor_df.copy().astype(float)
    n = len(df)
    if n == 0:
        return pd.Series(dtype=float), {}

    # winsorize raw columns
    df['NTL_w'] = winsorize_series(df['NTL'], *winsor_q)
    df['ND_w']  = winsorize_series(df['ND'], *winsor_q)
    df['BC_w']  = winsorize_series(df['BC'], *winsor_q)
    # SR_mean winsorize
    if 'SR_mean' in df.columns:
        df['SRm_w'] = winsorize_series(df['SR_mean'], *winsor_q)
    else:
        df['SRm_w'] = 0.0

    # BC transform
    df['BC_t'] = np.log(df['BC_w'] + bc_log_eps)

    # rank normalize each to [0,1]
    df['r_NTL'] = rank01(df['NTL_w'].values)
    df['r_ND']  = rank01(df['ND_w'].values)
    df['r_BC']  = rank01(df['BC_t'].values)
    df['r_SRm'] = rank01(df['SRm_w'].values)

    # combine (raw) including SR_mean
    raw = (weights.get('NTL', 0.0) * df['r_NTL'] +
           weights.get('ND', 0.0)  * df['r_ND'] +
           weights.get('BC', 0.0)  * df['r_BC'] +
           weights.get('SR_mean', 0.0) * df['r_SRm'])
    edgescore_rank01 = pd.Series(rank01(raw.values), index=df.index, name='EdgeScore_new')

    diagnostics = {
        'n': n,
        'ND_unique_ratio': float(df['ND'].nunique()) / float(n) if n > 0 else np.nan,
        'BC_skew': float(df['BC_w'].skew()) if 'BC_w' in df else np.nan,
        'SR_mean_skew': float(df['SRm_w'].skew()) if 'SRm_w' in df else np.nan,
        'EdgeScore_raw_mean': float((factor_df['NTL'] * weights.get('NTL',0.0) + factor_df['ND'] * weights.get('ND',0.0) + factor_df['BC'] * weights.get('BC',0.0)).mean())
    }
    return edgescore_rank01, diagnostics

# ---------------------------
# Main pipeline (unchanged logic but includes SR_mean)
# ---------------------------
def run_monthly_analysis(price_file=PRICE_FILE, cap_file=MARKET_CAP_FILE, output_folder=OUTPUT_FOLDER):
    logger.info("Loading data...")
    df_prices = pd.read_csv(price_file, index_col=0, parse_dates=True)
    df_prices.columns = df_prices.columns.astype(str)
    df_cap = pd.read_csv(cap_file, index_col=0, parse_dates=True)
    df_cap.columns = df_cap.columns.astype(str)

    rebalance_dates = df_prices.resample('M').last().index
    all_rows = []
    per_period_diags = []

    logger.info(f"Start monthly loop over {len(rebalance_dates)} rebalance dates.")
    for i in tqdm(range(len(rebalance_dates) - 1), desc="Monthly loop"):
        date = rebalance_dates[i]
        next_date = rebalance_dates[i + 1]
        past_prices = df_prices.loc[:date].tail(FACTOR_LOOKBACK_DAYS)
        factor_df = calculate_edgescore_metrics(past_prices)
        if factor_df is None or factor_df.empty:
            continue

        # Build robust edgescore_new (now includes SR_mean)
        es_new_series, diag = build_edgescore_new(factor_df)
        diag['date'] = date

        # forward returns
        try:
            cur_prices = df_prices.loc[date]
            fut_prices = df_prices.loc[next_date]
        except KeyError:
            continue

        common_codes = sorted(list(set(factor_df.index) & set(cur_prices.index) & set(fut_prices.index)))
        if len(common_codes) == 0:
            continue

        cur = cur_prices.reindex(common_codes).astype(float)
        fut = fut_prices.reindex(common_codes).astype(float)
        good_mask = (~cur.isna()) & (~fut.isna()) & (cur > 0)
        common_ok = cur.index[good_mask]
        if len(common_ok) == 0:
            continue

        cur = cur.reindex(common_ok)
        fut = fut.reindex(common_ok)
        fwd_ret = (fut.values / cur.values) - 1
        ret_series = pd.Series(fwd_ret, index=common_ok, name='fwd_ret')

        # market caps
        try:
            caps = df_cap.loc[df_cap.index.asof(date)].reindex(common_ok)
        except Exception:
            caps = pd.Series(index=common_ok, dtype=float)
        caps.name = 'market_cap'

        # assemble month_df
        month_df = pd.DataFrame(index=common_ok)
        month_df['NTL'] = factor_df['NTL'].reindex(common_ok)
        month_df['ND']  = factor_df['ND'].reindex(common_ok)
        month_df['BC']  = factor_df['BC'].reindex(common_ok)
        month_df['SR_mean'] = factor_df['SR_mean'].reindex(common_ok)
        month_df['EdgeScore_raw'] = factor_df['EdgeScore_raw'].reindex(common_ok)
        month_df['EdgeScore_new'] = es_new_series.reindex(common_ok)
        month_df['fwd_ret'] = ret_series.reindex(common_ok)
        month_df['market_cap'] = caps.reindex(common_ok).astype(float)
        month_df = month_df.dropna(subset=['fwd_ret'])

        if month_df.empty:
            continue

        diag['n_codes'] = len(month_df)
        per_period_diags.append(diag)

        month_df = month_df.reset_index().rename(columns={'index': 'code'})
        month_df['date'] = date
        all_rows.append(month_df)

    if not all_rows:
        logger.critical("No data to analyze after monthly loop. Exiting.")
        return

    master_df = pd.concat(all_rows, ignore_index=True)
    logger.info(f"Constructed master_df with {len(master_df)} rows, covering {master_df['date'].nunique()} months.")
    master_df.to_csv(os.path.join(output_folder, 'master_df_monthly_panel_with_SR.csv'), index=False)

    # metrics now include SR_mean for grouping too
    metrics = ['NTL', 'ND', 'BC', 'SR_mean', 'EdgeScore_new', 'EdgeScore_raw']
    group_mean_returns = {}
    per_metric_group_ts = {}

    for metric in metrics:
        logger.info(f"Processing metric: {metric}")
        master_df[f'{metric}_group'] = master_df.groupby('date')[metric].transform(lambda s: assign_deciles_robust(s, NUM_GROUPS))
        dfm = master_df.dropna(subset=[f'{metric}_group']).copy()
        dfm[f'{metric}_group'] = dfm[f'{metric}_group'].astype(int)
        def group_weighted_ret(group_df):
            valid = group_df[group_df['market_cap'] > 0].copy()
            if valid.empty:
                return np.nan
            w = valid['market_cap'] / valid['market_cap'].sum()
            return (valid['fwd_ret'] * w).sum()
        grp_ts = dfm.groupby(['date', f'{metric}_group'], observed=False).apply(group_weighted_ret)
        grp_df = grp_ts.unstack(level=1)
        per_metric_group_ts[metric] = grp_df
        mean_monthly = grp_df.mean(axis=0, skipna=True).reindex(range(NUM_GROUPS))
        group_mean_returns[metric] = mean_monthly
        grp_df.to_csv(os.path.join(output_folder, f'group_return_ts_{metric}.csv'))

    # plotting
    for metric, mean_monthly in group_mean_returns.items():
        plt.figure(figsize=(10, 6))
        values = (mean_monthly.values * 100)
        sns.barplot(x=[f'D{i}' for i in range(1, len(values)+1)], y=values, palette='viridis')
        plt.xlabel('Decile Group (D1 lowest -> D10 highest)', fontsize=12)
        plt.ylabel('Mean Monthly Return (%)', fontsize=12)
        plt.title(f'{metric} 分组平均月度收益率 (含 SR_mean)', fontsize=14)
        plt.grid(axis='y', linestyle='--', alpha=0.6)
        plt.tight_layout()
        outpath = os.path.join(output_folder, f'group_mean_monthly_{metric}.png')
        plt.savefig(outpath, dpi=150)
        #plt.show()

    # diagnostics
    df_diag = pd.DataFrame(per_period_diags).set_index('date').sort_index()
    df_diag.to_csv(os.path.join(output_folder, 'per_period_diagnostics_with_SR.csv'))
    logger.info("Saved diagnostics and outputs to output folder.")

if __name__ == "__main__":
    run_monthly_analysis()