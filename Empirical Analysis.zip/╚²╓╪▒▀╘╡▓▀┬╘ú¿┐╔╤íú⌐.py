import pandas as pd
import numpy as np
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx
from tqdm import tqdm
import os
import matplotlib.pyplot as plt

# ========== 0. 全局配置 & 回测参数 ==========
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
STOCK_LIST_FILE = 'stock_data/index_stocks_list.csv'
HS300_FILE = 'stock_data/HS300_monthly_return.csv'
MARKET_CAP_FILE = 'stock_data/market_cap.csv'  # <--- 修改点 1: 增加市值文件路径
OUTPUT_FOLDER = 'output'
MST_METRICS_CACHE_FILE = 'mst_metrics_cache_final.parquet'
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# --- 策略开关 ---
USE_MOMENTUM_FILTER = False
USE_VOLATILITY_FILTER = False

# --- 回测参数 ---
INITIAL_CAPITAL = 1_000_000
TOP_N_STOCKS = 20
COMMISSION_RATE = 0.001
SLIPPAGE_RATE = 0.0005
STAMP_DUTY_RATE = 0.001
VOLATILITY_LOOKBACK = 126
MOMENTUM_LOOKBACK = 63
VOLATILITY_CUTOFF = 0.8

# 中文字体配置
try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception:
    print("SimHei 字体未找到。")

# ========== 1. 数据准备 ==========
print("数据准备...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
df_cap = pd.read_csv(MARKET_CAP_FILE, index_col=0, parse_dates=True)  # <--- 修改点 1: 加载市值数据
daily_returns = df_prices.pct_change()
monthly_open = df_prices.resample('MS').first()
monthly_close = df_prices.resample('ME').last()  # 使用 'ME' (Month-End) 更标准


# ========== 2. MST指标计算函数 (保持不变) ==========
def calculate_mst_metrics(price_window):
    returns = price_window.pct_change().dropna()
    if len(returns) < 2 or len(returns.columns) < 2: return pd.DataFrame()
    corr = returns.corr().fillna(0)
    dist = np.sqrt(2 * (1 - corr))
    mst_sparse = minimum_spanning_tree(dist)
    G = nx.from_scipy_sparse_array(mst_sparse)
    node_mapping = {i: code for i, code in enumerate(corr.columns)}
    G = nx.relabel_nodes(G, node_mapping)
    if len(G.nodes) == 0: return pd.DataFrame()
    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except ValueError:
        levels = {node: 0 for node in G.nodes()}
    degs = dict(G.degree())
    bc = nx.betweenness_centrality(G, weight='weight')
    return pd.DataFrame({
        '股票代码': list(G.nodes()), 'NTL': [levels.get(n, 0) for n in G.nodes()],
        'ND': [degs.get(n, 0) for n in G.nodes()], 'BC': [bc.get(n, 0) for n in G.nodes()],
    })


# ========== 3. 生成或加载每月选股信号 (保持不变) ==========
if os.path.exists(MST_METRICS_CACHE_FILE):
    print(f"加载缓存文件: '{MST_METRICS_CACHE_FILE}'...")
    signals_df = pd.read_parquet(MST_METRICS_CACHE_FILE)
    print("指标加载完毕。")
else:
    print(f"未找到缓存文件。正在生成所有指标...")
    all_monthly_scores = []
    max_lookback = max(VOLATILITY_LOOKBACK, MOMENTUM_LOOKBACK)
    first_valid_date = df_prices.index[0] + pd.DateOffset(days=max_lookback)
    monthly_groups = df_prices[df_prices.index >= first_valid_date].groupby(pd.Grouper(freq='MS'))

    for period_start, price_window in tqdm(monthly_groups, desc="计算所有指标"):
        if len(price_window) < 20: continue
        metrics_df = calculate_mst_metrics(price_window)
        if metrics_df.empty: continue
        momentum_start = period_start - pd.DateOffset(days=MOMENTUM_LOOKBACK)
        vol_start = period_start - pd.DateOffset(days=VOLATILITY_LOOKBACK)
        momentum_end_price = price_window.iloc[-1]
        momentum_start_price = df_prices.loc[momentum_start:period_start].iloc[0]
        momentum = (momentum_end_price / momentum_start_price) - 1
        volatility = daily_returns.loc[vol_start:period_start].std() * np.sqrt(252)
        metrics_df['momentum'] = metrics_df['股票代码'].map(momentum)
        metrics_df['volatility'] = metrics_df['股票代码'].map(volatility)
        metrics_df['NTL_rank'] = metrics_df['NTL'].rank(pct=True)
        metrics_df['ND_rank'] = metrics_df['ND'].rank(pct=True)
        metrics_df['BC_rank'] = metrics_df['BC'].rank(pct=True)
        metrics_df['EdgeScore'] = metrics_df['NTL_rank'] + (1 - metrics_df['ND_rank']) + (1 - metrics_df['BC_rank'])
        metrics_df['月份'] = period_start
        all_monthly_scores.append(metrics_df)

    signals_df = pd.concat(all_monthly_scores).reset_index(drop=True)
    signals_df['生效月份'] = signals_df.groupby('股票代码')['月份'].shift(-1)
    signals_df = signals_df.dropna(subset=['生效月份'])
    signals_df.to_parquet(MST_METRICS_CACHE_FILE)
    print(f"缓存文件 '{MST_METRICS_CACHE_FILE}' 已保存。")

# ========== 4. 执行回测 (市值加权版) ==========
print("开始执行回测...")
cash = INITIAL_CAPITAL
positions = {}

rebalance_dates = sorted(signals_df['生效月份'].unique())
first_trade_date = pd.NaT
for date in rebalance_dates:
    if not pd.isna(date) and date in monthly_open.index:
        first_trade_date = date
        break

portfolio_history = []
if pd.notna(first_trade_date):
    start_point_date = first_trade_date - pd.DateOffset(days=1)
    portfolio_history.append({'日期': start_point_date, '净值': 1.0})

for date in tqdm(rebalance_dates, desc="逐月回测 (市值加权)"):
    if pd.isna(date) or date not in monthly_open.index: continue

    # 平仓逻辑 (不变)
    trade_prices = monthly_open.loc[date]
    for stock, shares in positions.items():
        if stock in trade_prices and not pd.isna(trade_prices[stock]):
            sell_price = trade_prices[stock] * (1 - SLIPPAGE_RATE)
            trade_value = shares * sell_price
            cash += trade_value * (1 - COMMISSION_RATE - STAMP_DUTY_RATE)
    positions = {}

    # 选股逻辑 (不变)
    candidate_stocks = signals_df[signals_df['生效月份'] == date].copy()
    if USE_MOMENTUM_FILTER: candidate_stocks = candidate_stocks[candidate_stocks['momentum'] > 0]
    if USE_VOLATILITY_FILTER:
        vol_cutoff_value = candidate_stocks['volatility'].quantile(VOLATILITY_CUTOFF)
        candidate_stocks = candidate_stocks[candidate_stocks['volatility'] < vol_cutoff_value]
    target_stocks = candidate_stocks.nlargest(TOP_N_STOCKS, 'EdgeScore')['股票代码'].tolist()

    # ==================== 修改点 2: 资金分配逻辑 ====================
    if target_stocks:
        # 寻找真实的交易日以获取市值
        future_dates = df_cap.index[df_cap.index >= date]
        if not future_dates.empty:
            actual_cap_date = future_dates[0]

            # 获取市值并过滤掉无效数据
            caps = df_cap.loc[actual_cap_date, target_stocks].dropna()

            if not caps.empty:
                # 计算市值权重
                weights = caps / caps.sum()
                capital_to_invest = cash

                # 按市值权重分配资金并买入
                for stock, weight in weights.items():
                    if stock in trade_prices and not pd.isna(trade_prices[stock]):
                        buy_price = trade_prices[stock] * (1 + SLIPPAGE_RATE)
                        if buy_price > 0:
                            # 按权重分配资金
                            allocated_capital = capital_to_invest * weight
                            # 计算买入股数和实际成本
                            shares_to_buy = allocated_capital / (buy_price * (1 + COMMISSION_RATE))
                            actual_cost = shares_to_buy * buy_price * (1 + COMMISSION_RATE)
                            # 更新现金和持仓
                            cash -= actual_cost
                            positions[stock] = shares_to_buy
    # ========================== 修改结束 ==========================

    # 月末净值计算 (不变)
    if date in monthly_close.index:
        portfolio_end_value = cash
        close_prices = monthly_close.loc[date]
        for stock, shares in positions.items():
            if stock in close_prices and not pd.isna(close_prices[stock]):
                portfolio_end_value += shares * close_prices[stock]
        portfolio_history.append({'日期': date, '净值': portfolio_end_value / INITIAL_CAPITAL})

df_backtest = pd.DataFrame(portfolio_history).set_index('日期').sort_index()
print("回测执行完毕。")

# ========== 5. 结果分析与可视化 (不变) ==========
print("正在生成结果报告...")
if df_backtest.empty or len(df_backtest) < 2:
    print("错误：没有生成足够的回测结果，无法绘图和计算绩效。")
else:
    # (此部分与您原始代码完全相同，包括基准对齐和绘图)
    try:
        hs300_all = pd.read_csv(HS300_FILE, parse_dates=['月份'], index_col='月份')
        strategy_start_date = df_backtest.index[0]
        hs300_sliced = hs300_all[hs300_all.index >= strategy_start_date]
        hs300_start_row = pd.DataFrame([hs300_sliced.iloc[0]], index=[strategy_start_date])
        hs300_start_row['沪深300收益率'] = 0.0
        hs300_sliced_with_start = pd.concat([hs300_start_row, hs300_sliced])
        hs300_aligned_net_value = (1 + hs300_sliced_with_start['沪深300收益率']).cumprod()
    except (FileNotFoundError, IndexError):
        hs300_aligned_net_value = None
        print(f"警告：找不到或处理基准文件 {HS300_FILE} 出错。")

    plt.figure(figsize=(16, 8))
    plt.plot(df_backtest.index, df_backtest['净值'], label='MST (市值加权)')
    if hs300_aligned_net_value is not None:
        plt.plot(hs300_aligned_net_value.index, hs300_aligned_net_value, label='沪深300', linestyle='--')
    plt.title('MST (市值加权) vs 沪深300', fontsize=16)
    plt.xlabel('日期');
    plt.ylabel('累计净值');
    plt.legend();
    plt.grid(True);
    plt.ylim(bottom=0)
    plt.savefig(os.path.join(OUTPUT_FOLDER, 'Strategy_Value_Weighted.png'))
    plt.show()


    # (绩效计算函数不变)
    def calculate_performance(net_value_series):
        if net_value_series is None or len(net_value_series.dropna()) < 2: return {"年化收益率": "N/A",
                                                                                   "年化波动率": "N/A",
                                                                                   "夏普比率": "N/A", "最大回撤": "N/A"}
        net_value_series = net_value_series.dropna()
        total_days = (net_value_series.index[-1] - net_value_series.index[0]).days
        if total_days == 0: return {"年化收益率": "0.00%", "年化波动率": "0.00%", "夏普比率": "0.00",
                                    "最大回撤": "0.00%"}
        annual_return = (net_value_series.iloc[-1] / net_value_series.iloc[0]) ** (365.25 / total_days) - 1
        returns = net_value_series.pct_change().dropna()
        annual_volatility = returns.std() * np.sqrt(12)
        sharpe_ratio = annual_return / annual_volatility if annual_volatility > 0 else 0
        cumulative_max = net_value_series.cummax()
        drawdown = (net_value_series - cumulative_max) / cumulative_max
        max_drawdown = drawdown.min()
        return {"年化收益率": f"{annual_return:.2%}", "年化波动率": f"{annual_volatility:.2%}",
                "夏普比率": f"{sharpe_ratio:.2f}", "最大回撤": f"{max_drawdown:.2%}"}


    strategy_performance = calculate_performance(df_backtest['净值'])
    benchmark_performance = calculate_performance(hs300_aligned_net_value)
    print("\n--- 策略绩效 (市值加权) ---");
    [print(f"{k}: {v}") for k, v in strategy_performance.items()]
    print("\n--- 基准绩效 (回测期内) ---");
    [print(f"{k}: {v}") for k, v in benchmark_performance.items()]