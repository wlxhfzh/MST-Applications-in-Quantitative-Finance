import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
import seaborn as sns
import logging
import datetime
from tqdm import tqdm
from scipy.sparse.csgraph import minimum_spanning_tree
import networkx as nx

# ==============================================================================
# ========== 0. 全局配置与日志初始化 ==========
# ==============================================================================
PRICE_FILE = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
MARKET_CAP_FILE = 'stock_data/market_cap.csv'
OUTPUT_FOLDER = 'output'
NUM_GROUPS = 10

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
log_filename = f"EdgeScore_Contemporaneous_analysis_log_{datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.log"
log_filepath = os.path.join(OUTPUT_FOLDER, log_filename)
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    handlers=[logging.FileHandler(log_filepath, mode='w', encoding='utf-8'),
                              logging.StreamHandler()])
logger = logging.getLogger(__name__)

try:
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
except Exception as e:
    logger.warning(f"设置中文字体失败: {e}。")

# ==============================================================================
# ========== 1. 数据加载与预处理 ==========
# ==============================================================================
logger.info("=" * 60)
logger.info("========== 1. 数据加载与预处理 ==========")
logger.info("=" * 60)

logger.info(f"STEP: 加载价格数据 '{PRICE_FILE}'...")
df_prices = pd.read_csv(PRICE_FILE, index_col=0, parse_dates=True)
df_prices = df_prices.loc['2025-01-01':'2025-12-31']  # 限制回测范围为2019-2020年
df_prices.columns = df_prices.columns.astype(str)

logger.info(f"STEP: 加载市值数据 '{MARKET_CAP_FILE}'...")
df_cap = pd.read_csv(MARKET_CAP_FILE, index_col=0, parse_dates=True)
df_cap = df_cap.loc['2025-01-01':'2025-12-31']  # 限制回测范围为2019-2020年
df_cap.columns = df_cap.columns.astype(str)

# ==============================================================================
# ========== 2. 核心逻辑：同期相关性分析 (EdgeScore) ==========
# ==============================================================================
logger.info("=" * 60)
logger.info("========== 2. 核心逻辑 (EdgeScore 同期相关性分析) ==========")
logger.info("=" * 60)


def calculate_edgescore_metrics(price_window):
    """
    修改后的函数，计算EdgeScore指标。
    """
    stock_codes = price_window.columns.astype(str)
    returns = price_window.pct_change().dropna()
    if len(returns) < 10 or len(stock_codes) < 2: return None

    corr = returns.corr().fillna(0)
    dist = np.sqrt(2 * (1 - corr))
    mst_sparse = minimum_spanning_tree(dist)
    G = nx.from_scipy_sparse_array(mst_sparse)
    node_mapping = {i: code for i, code in enumerate(stock_codes)}
    G = nx.relabel_nodes(G, node_mapping)
    if len(G.nodes) == 0: return None

    try:
        root = max(dict(G.degree()).items(), key=lambda x: x[1])[0]
        levels = dict(nx.single_source_shortest_path_length(G, root))
    except ValueError:
        levels = {node: 0 for node in G.nodes()}
    degs = dict(G.degree())
    bc = nx.betweenness_centrality(G, weight='weight')
    df = pd.DataFrame(index=list(G.nodes()))
    df['NTL'] = pd.Series(levels)
    df['ND'] = pd.Series(degs)
    df['BC'] = pd.Series(bc)
    df = df.fillna(0)

    # EdgeScore权重计算 (示例权重)
    df['EdgeScore'] = df['NTL'].rank(pct=True) + (1 - df['ND'].rank(pct=True)) + (1 - df['BC'].rank(pct=True))
    return df['EdgeScore']


# 按月对价格数据进行分组
monthly_groups = df_prices.groupby(pd.Grouper(freq='MS'))
all_monthly_returns = []

logger.info("开始逐月进行EdgeScore同期相关性分析...")
for month_start_date, price_window in tqdm(monthly_groups, desc="EdgeScore同期分析"):
    if len(price_window) < 2: continue

    # 1. 计算当月因子：用当月所有数据计算EdgeScore
    factor_series = calculate_edgescore_metrics(price_window)
    if factor_series is None: continue

    # 2. 计算当月收益：从月初到月末
    month_end_date = month_start_date.to_period('M').to_timestamp('M')
    try:
        start_price = df_prices.loc[df_prices.index.asof(month_start_date)]
        end_price = df_prices.loc[df_prices.index.asof(month_end_date)]
    except KeyError:
        continue
    monthly_returns = (end_price / start_price) - 1
    monthly_returns.name = '当月收益率'

    # 3. 获取当月市值的平均值或月初值作为权重
    market_caps = df_cap.loc[df_cap.index.asof(month_start_date)]
    market_caps.name = '市值'

    # 4. 合并当月数据
    month_df = pd.concat([factor_series, monthly_returns, market_caps], axis=1)
    month_df = month_df.dropna()

    if month_df.empty: continue

    # 5. 当月内部分组并计算收益
    # EdgeScore值越大，越接近网络的核心作用，降序排列
    month_df = month_df.sort_values(by='EdgeScore', ascending=False)


    def hard_cut_grouper(series, num_groups):
        ranked_series = series.rank(method='first')
        group_size = len(series) / num_groups
        group_assignments = np.ceil(ranked_series / group_size).astype(int)
        return [f'D{g}' for g in group_assignments]


    month_df['Group'] = hard_cut_grouper(month_df['EdgeScore'], NUM_GROUPS)


    def get_group_return(df):
        df_valid = df[df['市值'] > 0]
        if df_valid.empty: return 0.0
        weights = df_valid['市值'] / df_valid['市值'].sum()
        return (df_valid['当月收益率'] * weights).sum()


    group_returns_for_month = month_df.groupby('Group', observed=False).apply(get_group_return)

    # 记录这个月每个组的收益
    for group_name, group_return in group_returns_for_month.items():
        all_monthly_returns.append({
            '日期': month_start_date,
            'Group': group_name,
            '月度收益率': group_return
        })

if not all_monthly_returns:
    logger.critical("未能生成任何有效的分组收益率数据！分析终止。")
else:
    analysis_results = pd.DataFrame(all_monthly_returns)
    logger.info(f"同期分析成功完成，共记录 {len(analysis_results)} 条分组月度收益。")

    # ==============================================================================
    # ========== 3. 结果汇总与可视化 ==========
    # ==============================================================================
    logger.info("=" * 60)
    logger.info("========== 3. 结果汇总与可视化 ==========")
    logger.info("=" * 60)

    logger.info("STEP: 计算各组平均月度收益率...")
    mean_returns = analysis_results.groupby('Group')['月度收益率'].mean()

    logger.info(f"EdgeScore因子(同期分析)各组平均收益率计算结果:\n{mean_returns.to_string()}")

    group_labels = [f'D{i + 1}' for i in range(NUM_GROUPS)]
    mean_returns = mean_returns.reindex(group_labels, fill_value=0)

    plt.figure(figsize=(12, 7))
    sns.barplot(x=mean_returns.index, y=mean_returns.values)
    plt.title('EdgeScore分组 vs. 平均月度收益率 (2025q年)', fontsize=16)
    plt.xlabel('EdgeScore 分组 (D1: 最边缘 -> D10: 最核心)', fontsize=12)
    plt.ylabel('平均月度收益率', fontsize=12)
    plt.grid(axis='y', linestyle='--', alpha=0.7)

    output_path = os.path.join(OUTPUT_FOLDER, 'EdgeScore_factor_contemporaneous_2025.png')
    plt.savefig(output_path)
    logger.info(f"图表已成功保存至: {output_path}")
    plt.show()

logger.info("========== 全部分析完成 ==========")