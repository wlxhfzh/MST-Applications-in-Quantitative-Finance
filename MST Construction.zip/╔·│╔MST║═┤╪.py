import pandas as pd
import numpy as np
import networkx as nx
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

# Step 1: 读取对数收益率数据
file_path = 'stock_data/clean_log_returns_2019_2025.csv'
log_returns = pd.read_csv(file_path, index_col=0)

# 检查收益率数据中缺失值情况
total_nans = log_returns.isna().sum().sum()
print(f"收益率数据总缺失值数量：{total_nans}")

if total_nans > 0:
    print("每只股票的缺失值数量（非0表示该股票有缺失）：")
    print(log_returns.isna().sum())
    print("每一天的缺失值数量（非0表示当天有缺失）：")
    print(log_returns.isna().sum(axis=1))

    print("具体缺失值位置（日期, 股票）：")
    nan_positions = np.where(log_returns.isna())
    for row, col in zip(nan_positions[0], nan_positions[1]):
        print(f"日期: {log_returns.index[row]}, 股票: {log_returns.columns[col]}")
else:
    print("收益率数据没有缺失值。")

# Step 2: 设置窗口大小和滑动步长
window_size = 30  # 窗口大小：30个交易日
step_size = 10    # 步长：每10天更新一次

# Step 3: 初始化存储结果
all_clusters = []

# Step 4: 滑动窗口生成 MST 和聚类
for start_idx in range(0, len(log_returns) - window_size + 1, step_size):
    # 窗口范围
    end_idx = start_idx + window_size
    window_data = log_returns.iloc[start_idx:end_idx]
    start_date = window_data.index.min()
    end_date = window_data.index.max()

    # 4.1 计算相关性矩阵
    correlation_matrix = window_data.corr()

    # 4.2 转换为距离矩阵
    # 距离公式: sqrt(2 * (1 - 相关系数))
    distance_matrix = np.sqrt(2 * (1 - correlation_matrix))

    # 4.2.1 替换/过滤掉 NaN
    # 方法1：将 NaN 替换为一个较大值（如2），这样不会被选为 MST 的边
    distance_matrix = distance_matrix.fillna(2.0)

    # 4.3 构建图
    G = nx.Graph()
    for stock in distance_matrix.columns:
        G.add_node(stock)
    for i, stock1 in enumerate(distance_matrix.columns):
        for j, stock2 in enumerate(distance_matrix.columns):
            if i < j:
                weight = distance_matrix.loc[stock1, stock2]
                # 只添加有效的边
                if not np.isnan(weight):
                    G.add_edge(stock1, stock2, weight=weight)

    # 4.4 生成最小生成树 (MST)
    mst = nx.minimum_spanning_tree(G)

    # 4.5 提取 MST 特征
    node_features = []
    for node in mst.nodes:
        degree = mst.degree(node)
        neighbors = list(mst.neighbors(node))
        if neighbors:
            avg_weight = np.mean([mst.edges[node, neighbor]['weight'] for neighbor in neighbors])
        else:
            avg_weight = 0.0  # 或者 np.nan，取决于你的业务
        node_features.append([node, degree, avg_weight])

    node_features_df = pd.DataFrame(node_features, columns=['Stock', 'Degree', 'AvgWeight'])

    # 4.6 标准化特征
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(node_features_df[['Degree', 'AvgWeight']])

    # 4.7 使用 K-means 聚类
    kmeans = KMeans(n_clusters=4, random_state=42)
    node_features_df['Cluster'] = kmeans.fit_predict(features_scaled)

    # 计算聚类的 Silhouette 分数
    silhouette_avg = silhouette_score(features_scaled, node_features_df['Cluster'])
    print(f"窗口 {start_date} 至 {end_date}: Silhouette 分数 = {silhouette_avg:.4f}")

    # 保存结果
    all_clusters.append({
        "start_date": start_date,
        "end_date": end_date,
        "clusters": node_features_df[['Stock', 'Cluster']].groupby('Cluster')['Stock'].apply(list).to_dict()
    })

# Step 5: 保存聚类结果
clusters_output_path = 'optimized_clusters_summary.csv'
with open(clusters_output_path, 'w') as f:
    f.write("Start_Date,End_Date,Cluster_ID,Stocks\n")
    for cluster_info in all_clusters:
        start_date = cluster_info["start_date"]
        end_date = cluster_info["end_date"]
        for cluster_id, stocks in cluster_info["clusters"].items():
            f.write(f"{start_date},{end_date},{cluster_id},{','.join(stocks)}\n")
print(f"优化后的聚类结果保存至 {clusters_output_path}")