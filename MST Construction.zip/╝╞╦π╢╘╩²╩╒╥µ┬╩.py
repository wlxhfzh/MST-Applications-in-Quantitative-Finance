import pandas as pd
import numpy as np
import os


def calculate_log_returns():
    print("开始计算对数收益率...")

    # 加载清洗后的收盘价数据
    file_path = 'stock_data/clean_index_stocks_close_prices_2019_2025.csv'
    if not os.path.exists(file_path):
        print(f"错误: 找不到文件 {file_path}")
        return

    # 读取数据，将日期列设为索引
    df = pd.read_csv(file_path)
    df['日期'] = pd.to_datetime(df.iloc[:, 0])
    df.set_index('日期', inplace=True)
    df = df.iloc[:, 1:]  # 移除日期列（现在已是索引）

    print(f"加载了 {df.shape[1]} 只股票的收盘价数据")

    # 1. 先处理零值和极小值 (避免log(0)和log(接近0)的问题)
    epsilon = 1e-10  # 极小值阈值
    zero_mask = df <= epsilon
    zero_percentage = zero_mask.sum().sum() / (df.shape[0] * df.shape[1]) * 100
    print(f"数据中零值或极小值比例: {zero_percentage:.2f}%")

    # 将零值和极小值替换为NaN
    df = df.mask(zero_mask)

    # 2. 计算对数收益率 (避免警告)
    # r_t = ln(P_t/P_{t-1})
    log_returns = np.log(df.div(df.shift(1)))

    # 计算缺失值比例
    na_percentage = log_returns.isna().sum().sum() / (log_returns.shape[0] * log_returns.shape[1]) * 100
    print(f"对数收益率中缺失值比例: {na_percentage:.2f}%")

    # 3. 保存原始对数收益率
    log_returns.to_csv('stock_data/log_returns_2019_2025.csv')

    # 4. 清洗对数收益率数据
    # 4.1 移除缺失值过多的股票 (例如超过5%的数据缺失)
    missing_threshold = 0.05  # 5%
    missing_ratio = log_returns.isna().mean()
    valid_columns = missing_ratio[missing_ratio <= missing_threshold].index
    clean_log_returns = log_returns[valid_columns]

    # 4.2 处理剩余的缺失值 (可选择填充或移除行)
    # 方法1: 填充缺失值 - 使用股票的平均收益率填充
    # clean_log_returns = clean_log_returns.fillna(clean_log_returns.mean())

    # 方法2: 移除包含缺失值的行 (更严格，但可能损失数据)
    clean_log_returns = clean_log_returns.dropna()

    # 4.3 处理异常值 (可选) - 使用3倍标准差作为阈值
    std_dev = clean_log_returns.std()
    mean_returns = clean_log_returns.mean()

    upper_limit = mean_returns + 3 * std_dev
    lower_limit = mean_returns - 3 * std_dev

    # 创建异常值掩码 (对每一列单独应用限制)
    for col in clean_log_returns.columns:
        outlier_mask = (clean_log_returns[col] > upper_limit[col]) | (clean_log_returns[col] < lower_limit[col])
        # 将异常值替换为NaN
        clean_log_returns.loc[outlier_mask, col] = np.nan

    # 再次填充新产生的NaN (使用前向填充)
    clean_log_returns = clean_log_returns.fillna(method='ffill')

    # 5. 保存清洗后的对数收益率
    clean_log_returns.to_csv('stock_data/clean_log_returns_2019_2025.csv')

    # 打印统计信息
    print("\n对数收益率统计信息:")
    print(f"数据行数: {clean_log_returns.shape[0]}")
    print(f"数据列数: {clean_log_returns.shape[1]}")
    print(f"开始日期: {clean_log_returns.index.min().date()}")
    print(f"结束日期: {clean_log_returns.index.max().date()}")
    print(f"平均对数收益率: {clean_log_returns.mean().mean()}")
    print(f"对数收益率标准差: {clean_log_returns.std().mean()}")

    print(f"\n对数收益率数据已保存至 stock_data/log_returns_2019_2025.csv")
    print(f"清洗后的对数收益率数据已保存至 stock_data/clean_log_returns_2019_2025.csv")
    print(f"清洗后保留 {clean_log_returns.shape[1]}/{df.shape[1]} 只股票")


if __name__ == "__main__":
    calculate_log_returns()