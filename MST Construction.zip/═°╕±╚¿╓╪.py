#!/usr/bin/env python3
"""
Improved grid search for EdgeScore weights (NTL, ND, BC, SR_mean).

Features added / changes:
- MIN_MONTHS_LS filtering to avoid tiny-sample noise.
- Composite objective support (spearman, ls_tstat, ls_mean, composite).
- Save mean_by_group expanded into separate columns for easy inspection.
- Quick Train/Test (60/40) check for top-K configs.
- Optional SR month-level size neutralization (regression).
- Optional parallel evaluation (joblib) if available.
- Stable group assignment: rank -> qcut (fallback to cut).
- CLI options for master file, objective, n_jobs, min_months, neutralize SR.
- Outputs: weight_grid_results.csv, weight_grid_topk.csv, best_weights_rank*.png

Usage:
    python grid_search_edge_weights_improved.py --master output/master_df_monthly_panel_with_SR.csv

Author: assistant (adapted for your pipeline)
"""
import os
import argparse
import itertools
import json
import math
import numpy as np
import pandas as pd
from scipy.stats import rankdata, spearmanr
import matplotlib.pyplot as plt

# Try import joblib for parallelism (optional)
try:
    from joblib import Parallel, delayed
    JOBLIB_AVAILABLE = True
except Exception:
    JOBLIB_AVAILABLE = False

# ---------------------------
# Default Config (edit if needed)
# ---------------------------
DEFAULT_MASTER_CSV = 'output/master_df_monthly_panel_with_SR.csv'
OUTPUT_FOLDER = 'output'
NUM_GROUPS = 10
WINSOR_Q = (0.01, 0.99)
BOOTSTRAP_N = 2000
TOP_K = 5
MIN_MONTHS_LS = 12  # minimum number of months with valid LS to consider a combo
COMPOSITE_WEIGHTS = {'spearman': 0.7, 'ls_tstat': 0.3}

# default grids (you can override via CLI by editing script or passing a modified list)
GRID_NTL = [-0.5, 0.0, 0.1, 0.5, 1.0, 2.0, 3.0]
GRID_ND  = [0.0, -0.1, -0.2]
GRID_BC  = [0.0, -0.1, -0.2]
GRID_SR  = [-0.6, -0.3, -0.1, 0.0, 0.1, 0.3, 0.5, 0.6, 0.7, 1.0]

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ---------------------------
# Utilities
# ---------------------------
def winsorize_series(s: pd.Series, low_q=0.01, high_q=0.99) -> pd.Series:
    if s.dropna().empty:
        return s
    lo = s.quantile(low_q)
    hi = s.quantile(high_q)
    return s.clip(lo, hi)

def rank01_per_array(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr)
    if arr.size <= 1:
        return np.zeros_like(arr, dtype=float)
    r = rankdata(arr, method='average')  # 1..N
    return (r - 1) / (len(arr) - 1)

def assign_groups_by_rank(series_rank, n_groups=NUM_GROUPS):
    """
    series_rank: numeric rank (1..N or any increasing)
    returns integer group labels 0..n_groups-1 with fallback if qcut fails.
    """
    try:
        bins = pd.qcut(series_rank, q=n_groups, labels=False, duplicates='drop')
        return bins.astype('Int64')
    except Exception:
        # fallback to equal-sized bins by rank percent
        try:
            r = pd.Series(series_rank).rank(method='first')
            bins = pd.cut(r, bins=n_groups, labels=False)
            return bins.astype('Int64')
        except Exception:
            # ultimate fallback: modulo-based
            r = pd.Series(series_rank).rank(method='first').astype(int)
            return (r % n_groups).astype('Int64')

def compute_group_returns(df, group_col='grp_try'):
    """
    df must contain columns: date, grp_try, fwd_ret, market_cap
    returns DataFrame indexed by date with columns 0..NUM_GROUPS-1
    """
    def weighted_group_return(g):
        valid = g[g['market_cap'] > 0].copy()
        if valid.empty:
            return np.nan
        w = valid['market_cap'] / valid['market_cap'].sum()
        return (valid['fwd_ret'] * w).sum()
    # groupby apply may warn in newer pandas but it's fine
    grp_ts = df.groupby(['date', group_col], observed=False).apply(weighted_group_return)
    grp_df = grp_ts.unstack(level=1)
    # ensure columns 0..NUM_GROUPS-1 exist
    for i in range(NUM_GROUPS):
        if i not in grp_df.columns:
            grp_df[i] = np.nan
    grp_df = grp_df.reindex(columns=range(NUM_GROUPS))
    return grp_df

def long_short_stats_from_grp_df(grp_df, bootstrap_n=1000):
    ls = (grp_df[NUM_GROUPS-1] - grp_df[0]).dropna()
    n = len(ls)
    if n == 0:
        return {'n':0,'ls_mean':np.nan,'ls_std':np.nan,'ls_t':np.nan,'pos_frac':np.nan,'ci':(np.nan,np.nan), 'ls_ts': ls}
    mean = ls.mean()
    std = ls.std(ddof=1)
    tstat = mean / (std / math.sqrt(n)) if n>1 and std>0 else np.nan
    pos_frac = (ls > 0).mean()
    rng = np.random.default_rng(42)
    arr = ls.values
    bs_means = [rng.choice(arr, size=len(arr), replace=True).mean() for _ in range(bootstrap_n)]
    ci_low, ci_high = np.percentile(bs_means, [2.5,97.5]) if len(bs_means)>0 else (np.nan,np.nan)
    return {'n':n,'ls_mean':mean,'ls_std':std,'ls_t':tstat,'pos_frac':pos_frac,'ci':(ci_low,ci_high),'ls_ts': ls}

# ---------------------------
# Optional SR neutralization
# ---------------------------
def neutralize_sr_monthly(master_df, cap_col='market_cap', sector_col=None):
    """
    Per-month linear regression SR_mean ~ log(market_cap) + sector dummies (if sector_col provided).
    Returns a new column 'SR_neut' added to dataframe (aligned).
    """
    import statsmodels.api as sm
    out_rows = []
    for date, g in master_df.groupby('date'):
        g = g.copy()
        if g['SR_mean'].notna().sum() < 10:
            g['SR_neut'] = g['SR_mean'] - g['SR_mean'].mean()
            out_rows.append(g)
            continue
        X = pd.DataFrame()
        # log market cap
        if cap_col in g.columns:
            X['log_mcap'] = np.log(g[cap_col].replace(0, np.nan))
        else:
            X['log_mcap'] = 0.0
        if sector_col and sector_col in g.columns:
            dummies = pd.get_dummies(g[sector_col].fillna('NA'), prefix='sec', drop_first=True)
            X = pd.concat([X, dummies], axis=1)
        X = X.fillna(0.0)
        Xc = sm.add_constant(X)
        y = g['SR_mean'].fillna(g['SR_mean'].mean())
        try:
            model = sm.OLS(y, Xc).fit()
            g['SR_neut'] = model.resid
        except Exception:
            g['SR_neut'] = y - y.mean()
        out_rows.append(g)
    df_out = pd.concat(out_rows, ignore_index=True)
    return df_out

# ---------------------------
# Core evaluation for a single combo (extractable for parallel)
# ---------------------------
def evaluate_combo_on_proc(master_proc, combo, objective='spearman', bootstrap_n=500, min_months_ls=MIN_MONTHS_LS):
    w_ntl, w_nd, w_bc, w_sr = combo
    tmp = master_proc.copy()
    tmp['es_try'] = (w_ntl * tmp['r_NTL'] +
                     w_nd  * tmp['r_ND'] +
                     w_bc  * tmp['r_BC'] +
                     w_sr  * tmp['r_SRm'])
    tmp['rank_try'] = tmp.groupby('date')['es_try'].transform(lambda s: s.rank(method='first'))
    tmp['grp_try'] = tmp.groupby('date')['rank_try'].transform(lambda s: assign_groups_by_rank(s, NUM_GROUPS))
    grp_df = compute_group_returns(tmp, group_col='grp_try')
    mean_by_group = grp_df.mean(axis=0, skipna=True)
    idx = np.arange(len(mean_by_group))
    try:
        rho, p = spearmanr(idx, mean_by_group.values)
    except Exception:
        rho, p = (np.nan, np.nan)
    ls_stats = long_short_stats_from_grp_df(grp_df, bootstrap_n=bootstrap_n)
    # scoring
    if ls_stats['n'] < min_months_ls:
        score = -9999.0  # exclude
    else:
        if objective == 'spearman':
            score = rho if not np.isnan(rho) else -np.inf
        elif objective == 'ls_tstat':
            score = ls_stats['ls_t'] if not np.isnan(ls_stats['ls_t']) else -np.inf
        elif objective == 'ls_mean':
            score = ls_stats['ls_mean'] if not np.isnan(ls_stats['ls_mean']) else -np.inf
        elif objective == 'composite':
            s1 = rho if not np.isnan(rho) else 0.0
            s2 = ls_stats['ls_t'] if not np.isnan(ls_stats['ls_t']) else 0.0
            score = COMPOSITE_WEIGHTS['spearman'] * s1 + COMPOSITE_WEIGHTS['ls_tstat'] * s2
        else:
            score = rho
    # return dictionary (mean_by_group as list)
    return {
        'w_ntl': w_ntl, 'w_nd': w_nd, 'w_bc': w_bc, 'w_sr': w_sr,
        'score': score, 'spearman': rho, 'spearman_p': p,
        'ls_mean': ls_stats['ls_mean'], 'ls_std': ls_stats['ls_std'], 'ls_t': ls_stats['ls_t'],
        'ls_pos_frac': ls_stats['pos_frac'], 'ls_ci_low': ls_stats['ci'][0], 'ls_ci_high': ls_stats['ci'][1],
        'n_months_ls': ls_stats['n'],
        'mean_by_group': (mean_by_group.values.tolist() if mean_by_group is not None else [np.nan]*NUM_GROUPS)
    }

# ---------------------------
# Main grid function
# ---------------------------
def run_grid_search(master_csv, output_folder, grid_ntl, grid_nd, grid_bc, grid_sr,
                    winsor_q=WINSOR_Q, objective='spearman', bootstrap_n=BOOTSTRAP_N, top_k=TOP_K,
                    min_months_ls=MIN_MONTHS_LS, n_jobs=1, neutralize_sr=False):
    print("Loading master:", master_csv)
    if not os.path.exists(master_csv):
        raise FileNotFoundError(f"Master CSV not found: {master_csv}. Run pipeline first to produce it.")
    master = pd.read_csv(master_csv, parse_dates=['date'])
    required = ['date','code','NTL','ND','BC','SR_mean','fwd_ret','market_cap']
    missing = [c for c in required if c not in master.columns]
    if missing:
        raise ValueError(f"Master CSV missing required columns required for grid: {missing}")

    # Optional SR neutralization
    if neutralize_sr:
        print("Neutralizing SR_mean per month (size/sector) ...")
        sector_col = 'sector' if 'sector' in master.columns else None
        master = neutralize_sr_monthly(master, cap_col='market_cap', sector_col=sector_col)
        # rename column to SR_mean for downstream uniformity
        if 'SR_neut' in master.columns:
            master['SR_mean'] = master['SR_neut']

    # Precompute per-month winsor + rank01 for components, keep date col for later splitting
    print("Computing per-month winsorize + rank01 for components...")
    def process_group(g):
        g = g.copy()
        g['NTL_w'] = winsorize_series(g['NTL'], *winsor_q)
        g['ND_w']  = winsorize_series(g['ND'],  *winsor_q)
        g['BC_w']  = winsorize_series(g['BC'],  *winsor_q)
        g['SRm_w'] = winsorize_series(g['SR_mean'], *winsor_q)
        g['BC_t'] = np.log1p(g['BC_w'].values)
        g['r_NTL'] = rank01_per_array(g['NTL_w'].values)
        g['r_ND']  = rank01_per_array(g['ND_w'].values)
        g['r_BC']  = rank01_per_array(g['BC_t'].values)
        g['r_SRm'] = rank01_per_array(g['SRm_w'].values)
        return g
    master_proc = master.groupby('date', group_keys=False).apply(process_group).reset_index(drop=True)

    combos = list(itertools.product(grid_ntl, grid_nd, grid_bc, grid_sr))
    print(f"Grid size: {len(combos)} combinations.")
    results = []

    # Evaluate combos (optionally parallel)
    if n_jobs != 1 and JOBLIB_AVAILABLE:
        print(f"Running in parallel with n_jobs={n_jobs} (joblib)...")
        jobs = Parallel(n_jobs=n_jobs)(
            delayed(evaluate_combo_on_proc)(master_proc, combo, objective, bootstrap_n, min_months_ls)
            for combo in combos
        )
        results = jobs
    else:
        print("Running sequentially...")
        for i, combo in enumerate(combos, start=1):
            res = evaluate_combo_on_proc(master_proc, combo, objective, bootstrap_n, min_months_ls)
            results.append(res)
            if i % 50 == 0 or i == len(combos):
                print(f"Processed {i}/{len(combos)} combos...")

    # Convert to DataFrame, expand mean_by_group into columns
    res_df = pd.DataFrame(results)
    # Expand mean_by_group list into columns
    mbg = pd.DataFrame(res_df['mean_by_group'].tolist(), columns=[f'mean_grp_{i}' for i in range(NUM_GROUPS)])
    res_df = pd.concat([res_df.drop(columns=['mean_by_group']), mbg], axis=1)

    res_csv = os.path.join(output_folder, 'weight_grid_results.csv')
    res_df.to_csv(res_csv, index=False)
    print("Saved grid results to", res_csv)

    # sort and pick top-k by objective score
    res_sorted = res_df.sort_values('score', ascending=False).reset_index(drop=True)
    topk = res_sorted.head(top_k)
    topk_csv = os.path.join(output_folder, 'weight_grid_topk.csv')
    topk.to_csv(topk_csv, index=False)
    print("Top results (by objective):")
    print(topk[['w_ntl','w_nd','w_bc','w_sr','score','spearman','ls_mean','ls_t','n_months_ls']])

    # Plot best combos mean_by_group bar
    for rank_idx, row in topk.iterrows():
        w_ntl, w_nd, w_bc, w_sr = row['w_ntl'], row['w_nd'], row['w_bc'], row['w_sr']
        print(f"Plotting top #{rank_idx+1} weights: NTL={w_ntl}, ND={w_nd}, BC={w_bc}, SR={w_sr}")
        tmp = master_proc.copy()
        tmp['es_try'] = (w_ntl * tmp['r_NTL'] +
                         w_nd  * tmp['r_ND'] +
                         w_bc  * tmp['r_BC'] +
                         w_sr  * tmp['r_SRm'])
        tmp['rank_try'] = tmp.groupby('date')['es_try'].transform(lambda s: s.rank(method='first'))
        tmp['grp_try'] = tmp.groupby('date')['rank_try'].transform(lambda s: assign_groups_by_rank(s, NUM_GROUPS))
        grp_df_plot = compute_group_returns(tmp, 'grp_try')
        mean_by_group = (grp_df_plot.mean(axis=0, skipna=True) * 100)  # percent
        plt.figure(figsize=(8,5))
        plt.bar(range(1, len(mean_by_group)+1), mean_by_group.values, color=plt.cm.viridis(np.linspace(0,1,len(mean_by_group))))
        plt.xlabel('Decile Group (D1 lowest -> D10 highest)')
        plt.ylabel('Mean Monthly Return (%)')
        plt.title(f'Weights NTL={w_ntl},ND={w_nd},BC={w_bc},SR={w_sr}')
        plt.grid(axis='y', linestyle='--', alpha=0.5)
        outpng = os.path.join(output_folder, f'best_weights_rank{rank_idx+1}.png')
        plt.tight_layout()
        plt.savefig(outpng, dpi=150)
        plt.close()
        print("Saved", outpng)

    # Quick Train/Test evaluation for top-k
    print("Performing quick Train/Test evaluation for top-k:")
    months = sorted(master_proc['date'].unique())
    ntrain = max(1, int(len(months) * 0.6))
    train_months = months[:ntrain]; test_months = months[ntrain:]
    train = master_proc[master_proc['date'].isin(train_months)].copy()
    test  = master_proc[master_proc['date'].isin(test_months)].copy()

    def eval_on_df(df, w):
        w_ntl,w_nd,w_bc,w_sr = w
        tmp = df.copy()
        tmp['es_try'] = w_ntl*tmp['r_NTL'] + w_nd*tmp['r_ND'] + w_bc*tmp['r_BC'] + w_sr*tmp['r_SRm']
        tmp['rank_try'] = tmp.groupby('date')['es_try'].transform(lambda s: s.rank(method='first'))
        tmp['grp_try'] = tmp.groupby('date')['rank_try'].transform(lambda s: assign_groups_by_rank(s, NUM_GROUPS))
        grp_df = compute_group_returns(tmp, 'grp_try')
        mean_by_group = grp_df.mean(axis=0, skipna=True)
        rho,_ = spearmanr(np.arange(len(mean_by_group)), mean_by_group.values) if mean_by_group.notna().sum()>0 else (np.nan, np.nan)
        ls_stats = long_short_stats_from_grp_df(grp_df, bootstrap_n=500)
        return {'rho':rho,'ls_mean':ls_stats['ls_mean'],'ls_t':ls_stats['ls_t'],'n_months':ls_stats['n']}

    for idx, row in topk.iterrows():
        w = (row['w_ntl'],row['w_nd'],row['w_bc'],row['w_sr'])
        tr = eval_on_df(train, w)
        te = eval_on_df(test, w)
        print(f"Top#{idx+1} {w} -> Train rho {tr['rho']:.3f}, ls_mean {tr['ls_mean']:.4f}, Test rho {te['rho']:.3f}, ls_mean {te['ls_mean']:.4f}, Test months {te['n_months']}")

    print("Grid search complete. Review results CSVs and plots in output folder.")

# ---------------------------
# CLI
# ---------------------------
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Grid search EdgeScore weights (improved)")
    parser.add_argument('--master', type=str, default=DEFAULT_MASTER_CSV, help='master panel CSV path (with SR_mean)')
    parser.add_argument('--out', type=str, default=OUTPUT_FOLDER, help='output folder')
    parser.add_argument('--objective', type=str, default='spearman', choices=['spearman','ls_tstat','ls_mean','composite'], help='objective to maximize')
    parser.add_argument('--min_months', type=int, default=MIN_MONTHS_LS, help='min months with valid LS to accept combo')
    parser.add_argument('--n_jobs', type=int, default=1, help='number of parallel jobs (requires joblib)')
    parser.add_argument('--topk', type=int, default=TOP_K, help='how many best combos to save/plot')
    parser.add_argument('--neutralize_sr', action='store_true', help='if set, neutralize SR_mean by log(market_cap) + sector per month before grid')
    args = parser.parse_args()

    run_grid_search(master_csv=args.master, output_folder=args.out,
                    grid_ntl=GRID_NTL, grid_nd=GRID_ND, grid_bc=GRID_BC, grid_sr=GRID_SR,
                    objective=args.objective, bootstrap_n=BOOTSTRAP_N, top_k=args.topk,
                    min_months_ls=args.min_months, n_jobs=args.n_jobs, neutralize_sr=args.neutralize_sr)