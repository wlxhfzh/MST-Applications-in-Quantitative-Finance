import akshare as ak
import pandas as pd

df = ak.stock_zh_index_daily_em(symbol="sh000300")
df['date'] = pd.to_datetime(df['date'])
df = df.set_index('date').sort_index()

# 月末收盘
monthly_close = df['close'].resample('M').last()
monthly_return = monthly_close.pct_change().rename('沪深300收益率')
monthly_return = monthly_return.dropna().reset_index()
monthly_return.rename(columns={'date': '月份'}, inplace=True)

print(monthly_return.head())
monthly_return.to_csv(r"D:\JetBrains\pythonProject1\MST\stock_data\HS300_monthly_return.csv", index=False)
print("已保存: D:\\JetBrains\\pythonProject1\\MST\\stock_data\\HS300_monthly_return.csv")