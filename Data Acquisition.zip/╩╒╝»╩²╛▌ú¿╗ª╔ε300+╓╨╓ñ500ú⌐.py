import akshare as ak
import pandas as pd
import numpy as np
import os
import time
from datetime import datetime


def main():
    print("开始收集沪深300和中证500成分股数据...")

    # 创建数据存储目录
    if not os.path.exists('stock_data'):
        os.makedirs('stock_data')

    # 1. 获取沪深300和中证500成分股
    print("获取指数成分股...")
    hs300_stocks = ak.index_stock_cons_csindex(symbol="000300")
    print(f"沪深300成分股数量: {len(hs300_stocks)}")

    zz500_stocks = ak.index_stock_cons_csindex(symbol="000905")
    print(f"中证500成分股数量: {len(zz500_stocks)}")

    # 合并并去重
    hs300_stocks['指数'] = '沪深300'
    zz500_stocks['指数'] = '中证500'
    all_index_stocks = pd.concat([hs300_stocks, zz500_stocks], ignore_index=True)
    all_index_stocks = all_index_stocks.drop_duplicates(subset=['成分券代码'])
    print(f"合并后总共选取了 {len(all_index_stocks)} 只股票")

    # 保存成分股列表
    all_index_stocks.to_csv('stock_data/index_stocks_list.csv', index=False, encoding='utf-8-sig')

    # 股票代码列表
    stock_codes = all_index_stocks['成分券代码'].tolist()

    # 2. 创建一个空的DataFrame来存储所有股票的收盘价
    all_close_prices = pd.DataFrame()

    # 3. 逐个获取股票的历史数据
    print("开始收集历史价格数据...")
    for i, code in enumerate(stock_codes):
        try:
            # 根据代码格式处理（akshare需要纯数字代码）
            if '.' in code:
                pure_code = code.split('.')[0]
            else:
                pure_code = code

            # 获取单个股票的历史数据
            stock_data = ak.stock_zh_a_hist(symbol=pure_code,
                                            period="daily",
                                            start_date="20190101",
                                            end_date="20250910",
                                            adjust="qfq")  # qfq为前复权

            if not stock_data.empty:
                # 设置索引为日期
                stock_data['日期'] = pd.to_datetime(stock_data['日期'])
                stock_data.set_index('日期', inplace=True)

                # 只保留收盘价，并重命名列为股票代码
                close_price = stock_data['收盘'].rename(code)

                # 添加到总DataFrame
                if all_close_prices.empty:
                    all_close_prices = pd.DataFrame(close_price)
                else:
                    all_close_prices = pd.concat([all_close_prices, close_price], axis=1)

            # 进度报告
            if (i + 1) % 50 == 0 or i == len(stock_codes) - 1:
                print(f"已处理 {i + 1}/{len(stock_codes)} 只股票")

            # 防止频繁请求API
            time.sleep(0.5)

        except Exception as e:
            print(f"获取股票 {code} 数据时出错: {e}")

    # 4. 保存原始数据
    all_close_prices.to_csv('stock_data/raw_index_stocks_close_prices_2019_2025.csv')
    print("原始数据已保存")

    # 5. 数据清洗处理
    print("开始数据清洗...")

    # 5.1 处理缺失值 - 只保留数据较完整的股票（例如至少有80%的交易日有数据）
    min_samples = int(len(all_close_prices) * 0.8)
    filtered_df = all_close_prices.loc[:, all_close_prices.count() >= min_samples]
    print(f"过滤后保留 {filtered_df.shape[1]}/{all_close_prices.shape[1]} 只股票")

    # 5.2 填充剩余的缺失值（前向填充，再后向填充）
    clean_df = filtered_df.fillna(method='ffill').fillna(method='bfill')

    # 5.3 计算日收益率（用于后续MST计算）
    returns_df = clean_df.pct_change().dropna()

    # 6. 保存清洗后的数据
    clean_df.to_csv('stock_data/clean_index_stocks_close_prices_2019_2025.csv')
    returns_df.to_csv('stock_data/index_stocks_daily_returns_2019_2025.csv')

    # 7. 数据验证
    print("进行数据验证...")
    print(f"数据范围: {clean_df.index.min()} 到 {clean_df.index.max()}")
    print(f"清洗后股票数量: {clean_df.shape[1]}")
    print(f"交易日数量: {clean_df.shape[0]}")

    # 8. 统计信息
    missing_rate = (clean_df.isna().sum() / len(clean_df)) * 100
    missing_stats = {
        "最大缺失率": missing_rate.max(),
        "平均缺失率": missing_rate.mean(),
        "缺失率>5%的股票数": (missing_rate > 5).sum()
    }

    with open('stock_data/data_quality_report.txt', 'w', encoding='utf-8') as f:
        f.write("数据质量报告\n")
        f.write(f"收集时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"数据时间范围: {clean_df.index.min()} 到 {clean_df.index.max()}\n")
        f.write(f"原始股票数: {all_close_prices.shape[1]}\n")
        f.write(f"清洗后股票数: {clean_df.shape[1]}\n")
        f.write(f"交易日数量: {clean_df.shape[0]}\n\n")
        f.write("缺失值统计:\n")
        for key, value in missing_stats.items():
            f.write(f"{key}: {value}\n")

    print("数据收集与处理完成！")
    print(f"所有文件已保存至 'stock_data' 目录")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"程序执行出错: {e}")