import pandas as pd
import tushare as ts
from tqdm import tqdm
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

# ========== 1. 配置 ==========
TUSHARE_TOKEN = '3b623df9ab56ac478b6a3621fcebf05d14e5c3107d2a18b25e9a5e71'
MAX_WORKERS = 10  # 保持多线程


# 【【【 自定义限速器配置 】】】
class RateLimiter:
    def __init__(self, max_calls, period):
        """
        初始化限速器
        :param max_calls: 最大调用次数
        :param period: 时间窗口（秒）
        """
        self.max_calls = max_calls
        self.period = period
        self.calls = []

    def consume(self):
        """
        消耗一个请求，确保限速规则不被打破
        """
        current_time = time.time()
        # 移除过期的调用记录
        self.calls = [call for call in self.calls if call > current_time - self.period]

        if len(self.calls) >= self.max_calls:
            # 如果超出限制，等待直到可以发起新的请求
            sleep_time = self.calls[0] + self.period - current_time
            time.sleep(sleep_time)

        # 添加当前时间戳到调用记录
        self.calls.append(current_time)


bucket = RateLimiter(650, 60)  # 每分钟最多650次请求

STOCK_LIST_FILE = 'stock_data/index_stocks_list.csv'
OUTPUT_FOLDER = 'stock_data'
OUTPUT_MARKET_CAP_FILE = os.path.join(OUTPUT_FOLDER, 'market_cap.csv')
OUTPUT_TURNOVER_VALUE_FILE = os.path.join(OUTPUT_FOLDER, 'turnover_value.csv')
START_DATE = "20190101"
END_DATE = "20251231"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# 全局初始化
if TUSHARE_TOKEN == '在这里替换成您从Tushare官网复制的Token字符串':
    print("错误：请先在代码中填入您的Tushare Token！")
    exit()
pro = ts.pro_api(TUSHARE_TOKEN)
print("Tushare Pro接口初始化成功。")


def fetch_daily_data_dual_api(date):
    """
    【核心修正】: 使用双API，分别获取市值和交易额
    """
    try:
        # 使用限速器，确保不会超速
        bucket.consume()
        # API 1: daily_basic 获取市值 (total_mv)
        df_basic = pro.daily_basic(trade_date=date, fields='ts_code,trade_date,total_mv')

        bucket.consume()
        # API 2: daily 获取交易额 (amount)
        df_daily = pro.daily(trade_date=date, fields='ts_code,trade_date,amount')

        if df_basic.empty or df_daily.empty:
            return None

        # 合并两个DataFrame
        df_merged = pd.merge(df_basic, df_daily, on=['ts_code', 'trade_date'])
        return df_merged

    except Exception as e:
        print(f"获取日期 {date} 的数据时发生异常: {e}")
        return None


def main():
    """主执行函数"""
    try:
        target_column = '成分券代码'
        df_stock_list = pd.read_csv(STOCK_LIST_FILE, encoding='utf-8', engine='python')
        stock_codes_raw = df_stock_list[target_column].apply(lambda x: str(x).zfill(6)).unique().tolist()
        print(f"成功读取了 {len(stock_codes_raw)} 只唯一的股票代码。")
    except Exception as e:
        print(f"读取股票列表时出错: {e}")
        return

    trade_dates_df = pro.trade_cal(exchange='', start_date=START_DATE, end_date=END_DATE)
    trade_dates = trade_dates_df[trade_dates_df['is_open'] == 1]['cal_date'].tolist()

    all_daily_data = []
    print(
        f"开始从Tushare并行获取 {len(trade_dates)} 个交易日的市值和交易额数据（使用 {MAX_WORKERS} 个线程和智能限速）...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        future_to_date = {executor.submit(fetch_daily_data_dual_api, date): date for date in trade_dates}
        for future in tqdm(as_completed(future_to_date), total=len(trade_dates), desc="并行获取数据"):
            result = future.result()
            if result is not None and not result.empty:
                all_daily_data.append(result)

    if not all_daily_data:
        print("错误：未能从Tushare获取到任何数据。请检查您的Token和网络。")
        return

    print("\n数据获取完毕，正在整合和格式化...")
    full_df = pd.concat(all_daily_data)

    full_df['code'] = full_df['ts_code'].str[:6]
    full_df['trade_date'] = pd.to_datetime(full_df['trade_date'])
    full_df = full_df[full_df['code'].isin(stock_codes_raw)]

    # 创建市值DataFrame (total_mv单位: 万元 -> 元)
    market_cap_df = full_df.pivot_table(index='trade_date', columns='code', values='total_mv') * 10000

    # 【核心修正】: 从正确的列 'amount' 创建交易额DataFrame (amount单位: 千元 -> 元)
    turnover_df = full_df.pivot_table(index='trade_date', columns='code', values='amount') * 1000

    market_cap_df.to_csv(OUTPUT_MARKET_CAP_FILE)
    print(f"市值数据已成功保存到: {OUTPUT_MARKET_CAP_FILE}")
    turnover_df.to_csv(OUTPUT_TURNOVER_VALUE_FILE)
    print(f"交易额数据已成功保存到: {OUTPUT_TURNOVER_VALUE_FILE}")
    print("\n全部任务完成！")


if __name__ == '__main__':
    main()